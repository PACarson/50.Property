/**
 * ═══════════════════════════════════════════════════════════════════════
 * PROPERTY OS — 00_File_Map.js
 * 系统地图（开发导航 / File Responsibilities & Module Relationships）
 * ═══════════════════════════════════════════════════════════════════════
 *
 * 号段状态：Reserved 900-949（ADR-P03，非 Locked）。待未来 Ecosystem
 * Registry 统一确认后，再正式 Assign，不在此阶段强行核对。
 *
 * 详细程度分层原则：Phase 1-2 模块提供完整 Purpose/Input/Output/
 * Dependencies/Called By；Phase 3+ 模块仅列出 Purpose 与 Status
 * （避免 Speculative Design）。
 *
 * 关联文件（不属于本文件编号体系，皆为 Contract Design 阶段产出）：
 *   - 00_ADR_Log.js                       — ADR-P01~P13 正式记录
 *   - PropertyOS_DomainModel.md           — 跨 Engine 共用领域模型
 *   - ObligationEngine_VerticalSlice.md   — 912/913 完整 Vertical Slice
 *
 * ★ CURRENT DEPLOYMENT MANIFEST（2026-08-17，每次同步真实 GAS 项目时
 * 核对这份清单，逐一比对——散落在各次对话记录里的"这个文件改了"很
 * 容易漏掉，这份清单才是当下应该存在于 GAS 项目里的完整文件集）：
 *
 *   实际推送到 GAS 的文件（.claspignore 排除治理 .js/.md 与 Node-only
 *   测试文件，见该文件本身）：
 *   900_PropertyConfig.js            ← 含全部 DLP/Evidence 枚举、8 张
 *                                       新表 SHEET_NAMES、8 个新
 *                                       ID_PREFIXES（DEFECT 复用既有
 *                                       保留前缀，Evidence 复用
 *                                       DOCUMENT 前缀）
 *   901_PropertySchema.js            ← ensureSheetSchema_ 现有
 *                                       per-execution 缓存；Property
 *                                       新增 DevelopmentName/UnitLabel
 *                                       （ADR-P17，Additive 追加在
 *                                       columns 最后）；8 张 DLP/
 *                                       Evidence 新表 Schema +
 *                                       initDefectEngineSchema_/
 *                                       initDocumentEngineSchema_
 *                                       ★ DefectItem 新增 ItemID/
 *                                       SubCategory/Remark，20 栏
 *                                       reorder（非 append，与
 *                                       Property 的 ADR-P17 模式不同）
 *                                       ——ADR-P18，2026-08-24～26
 *   902_PropertyIdentity.js          ← 含 generatePropertyId_（910）+
 *                                       8 个 DLP/Evidence 用途的
 *                                       generateXId_
 *   903_PropertyEventDefinitions.js  ← 含 Property/Obligation 既有
 *                                       事件 + 12 个 DLP/Evidence 新
 *                                       事件（逐 Phase 新增，非一次性
 *                                       预先列出）
 *   910_PropertyAssetEngine.js       ← createProperty/updateProperty
 *                                       开放 DevelopmentName/UnitLabel
 *                                       （ADR-P17；updateProperty 本身
 *                                       用 denylist 不用 allowlist，
 *                                       不需要改逻辑）
 *   911_DocumentEngine.js            ← 新文件（Phase 5，2026-08-17）。
 *                                       Evidence 最小范围，非完整
 *                                       Document Library。Drive
 *                                       Adapter 隔离在
 *                                       saveEvidenceFile_ 一处
 *   912_ObligationEngine.js          ← recordPayment/reversePayment 的
 *                                       Event Payload 含 category
 *   913_ObligationScheduler.js
 *   918_DefectEngine.js              ← 新文件（Phase 2-3-4-6-7，
 *                                       2026-08-17）。PropertyCase +
 *                                       DefectItem + DailyProgressCheck
 *                                       + Correspondence +
 *                                       RectificationEvent +
 *                                       SecondaryDamage +
 *                                       PropertyCaseTimeline 全部
 *                                       Command/Query
 *   922_DashboardAdapter.js          ← Phase 8（2026-08-17）新增
 *                                       getDlpCaseDashboard/
 *                                       getCaseTimeline/
 *                                       listDefectItemsForDashboard，
 *                                       既有 Obligation 相关函式未动
 *   945_OperatorConsole.html
 *   946_OperatorConsoleServer.js
 *   990_TestKit.js
 *   991_Tests_ObligationEngine.js
 *   992_Tests_PureLogic.js
 *   993_Tests_FullLifecycle.js
 *   994_Tests_ExtendedPlatform.js
 *   995_RunAllTests.js
 *   996_Tests_PropertyAssetEngine.js
 *
 *   （共 19 个 .js/.html 文件推送到真实 GAS。997_Tests_DefectEngine.js
 *   ——DLP 新增部分的正式 GAS-native 测试——尚未建立，Phase 11，未开始；
 *   目前 DLP 相关验证是本地 GasShim 预检 + CC 逐 Phase 真实部署 smoke
 *   test，非正式测试套件的一部分，见 MANUAL_VERIFICATION_CHECKLIST.md。
 *   若真实 GAS 专案的文件数量或任一文件内容与此不符，先同步再跑
 *   测试——大部分"莫名其妙的 undefined"报错都是这里没对齐，不是逻辑
 *   真的错了。）
 *
 *   ★ ADDENDUM（2026-08-24～26，Phase 11 对话窗口新增，不改上面
 *   2026-08-17 原文）——上面清单在两轮真实部署后已经过时，本次只补
 *   本窗口有把握、直接核实过的部分，不假装把整份 manifest 全部
 *   重新对过：
 *
 *   本窗口新增并已部署到真实 GAS 的文件（CC 已确认部署 (a)(b)(c) 三步
 *   成功，见 00_Project_State.js CHANGELOG 2026-08-24～26 / ADR-P18）：
 *     ONETIME_Phase11_DefectImporter.js — 上一个对话窗口新建（Phase
 *       11 一开始），当时就没有补进这份 File Map，本窗口发现这个既有
 *       缺口一并补上。真实 Defect Report 批次汇入用的一次性工具，
 *       staging 表 + dry-run/real-run 两阶段、以 OriginalReference
 *       为 durable dedup key。本窗口新增 ItemID/SubCategory/Remark 三
 *       个 staging 欄位支援。Phase 11 DefectItem onboarding 验证完成
 *       後可删除（见档案自己的开头说明）。
 *     ONETIME_Phase11_DefectItemSchemaReorderMigration.js — 本窗口
 *       新建。把真实 DefectItems 表从 migration 前的 17 栏 schema
 *       转成 CC 指定顺序的新 20 栏 schema，以栏位名字逐列重新映射
 *       既有资料，非按位置搬移。CC 已在真实 GAS 项目手动执行一次，
 *       Logger 回报 MIGRATION SUCCESS。同样是一次性工具，语意上跟
 *       Importer 同类——是否比照 Importer 保留到 Phase 11 完全结束
 *       再删，还是现在就可以删，未问过 CC——★ 2026-08-26 已问过、
 *       已回答：CC 决定两者都暂时保留，等真实 onboarding 全部完成、
 *       确认不再需要 rollback/rerun 后再议（见 00_Review_History.js
 *       REVIEW-005 Next Steps）。
 *
 *   ★ 已知落差，本窗口未处理（如实记录，不是修好了）：上面
 *   2026-08-17 原文清单也没有 947_DlpConsoleServer.js /
 *   948_MobileConsole.html（Phase 9/10，2026-08-19 才建立，比这份
 *   manifest 原文晚两天）——这是本窗口之前就存在的落差，不是这次造成
 *   的，但本窗口没有去核实/补齐这两个文件的条目（不在这次 CC 交代
 *   的范围内，也没有重新核实这两个文件目前真实内容的证据）。整份
 *   manifest 建议找一次机会重新完整核对一遍，而不是继续用这种
 *   一次补一点的方式维护。
 *   ★ 2026-08-26 UPDATE：上面这段"建议找机会重新完整核对"在本次
 *   housekeeping（BL-4，CC 2026-08-26 明确指示执行）已经做了——947/948
 *   在下方 §2 Runtime Layer 区块其实早就有完整的 Purpose/Dependencies/
 *   Status 条目（本次核实内容仍然正确），只有最上面这份 2026-08-17
 *   flat 部署清单没跟上；已在这段与下方 §2 947/948 条目本身修正
 *   Status（真机验证 REVIEW-002 已 PRODUCTION-READY，先前误标未验证）。
 *
 *   ★★ 2026-08-26 HOUSEKEEPING ADDENDUM（BL-4 全面重审，CC 明确指示
 *   "两条线 parallel 进行"——CC 同时用真实资料跑 DLP workflow，
 *   Claude 同时做这次治理一致性稽核，互不等待）：
 *
 *   本次新增/修改并已同步补上条目的档案：
 *     ONETIME_Phase11_DefectItemSchemaConsolidationMigration.js —
 *       ADR-P19 consolidation migration，与上面两个 ONETIME_Phase11_*
 *       档案同类，同样的保留/删除时机决定（见上一条）。CC 已在真实
 *       GAS 项目手动执行成功（Execution log 确认，2026-08-26）。
 *     local_precheck_test_911.js / _918.js / _922.js /
 *       _phase11_schema_migration.js /
 *       _phase11_defectitem_reorder_migration.js /
 *       _phase11_schema_consolidation_migration.js / GasShim.js — 这些
 *       先前完全没有条目，本次在下方新增「§5a LOCAL PRECHECK TESTING
 *       CONVENTION」小节统一说明，不逐档重复。
 *     README.md / Phase11_RealDataOnboarding_Checklist.md /
 *       DLP_Defect_Case_Engine_Phase0_Audit.md — 补进下方"纯治理文件"
 *       清单。
 *     runPhase5SmokeTest.js — 一次性 Phase 5 smoke test 脚本，已完成
 *       历史任务，非现役 Runtime 的一部分，纯供参考不需要正式 File Map
 *       条目，此处提及即可。
 *
 *   本次发现、评估后判定"确实存在、evidence-based"的落差，已直接修正
 *   （详见对应条目本身的 housekeeping 修正说明，或本文件下方新增
 *   小节）：
 *     - 947/948 Status（本文件本节）：真机验证早已 PRODUCTION-READY
 *       （REVIEW-002），File Map 之前没跟上，已修正。
 *     - 910 Status（§2 Runtime Layer）：真实 GAS 确认早已完成
 *       （00_Project_State.js 已记录），File Map 之前没跟上，已修正。
 *     - 00_Project_State.js 页首 ADR 状态摘要行：误列不存在的 "P16"、
 *       遗漏了实际存在的 P11-P14——已在该档案本身修正（不在本档案，
 *       但一并记录於此供交叉参照）。
 *
 *   本次发现、但判定"不该由 housekeeping 自行处理"、记入 Backlog 的
 *   落差（见 00_Product_Backlog.js BL-5）：
 *     - ADR-P17 缺档：多处（901_PropertySchema.js 注解、本档案上方
 *       2026-08-17 清单、ADR-P18/P19 的 Related ADRs）都把 ADR-P17
 *       当成已存在、已批准的正式决定引用（Property
 *       DevelopmentName/UnitLabel 用 Additive 而非 Reorder），但
 *       00_ADR_Log.js 里没有 ADR-P17 自己的正式条目——内容涉及还原
 *       一个 Claude 没有亲身参与的历史决策，不是排版/编号问题，刻意
 *       不擅自补写完整 ADR 内容。
 *     - 一批确认已死、无法执行的孤立档案：TestKit.js、
 *       runAllTests.js、900_Tests_Foundation.js、
 *       912_Tests_ObligationEngine.js、919_Tests_ObligationIntegration.js、
 *       999_Tests_PlatformVerification.js——彼此以
 *       require('../shim/GasShim')、require('./tests/...') 等路径互相
 *       引用，但 tests/ 与 shim/ 两个子目录在目前 repository 里根本不
 *       存在（已实际执行 node runAllTests.js 确认，直接抛
 *       "Cannot find module" 錯誤）。本档案页尾 §5 Testing Layer
 *       本身早就写明"原本的 property-os-tests/（Node 本地沙箱）已从
 *       本项目移除"（2026-07-29），00_Project_State.js 也独立确认
 *       "property-os-tests/ 已不存在"——这批档案就是那次应该被移除、
 *       但实际上仍留在 repository 里的遗留物。删除档案本身属于
 *       "确实存在的一致性问题"，本次已经从交付给 CC 的档案集里移除
 *       （不在这次回传的档案清单内）；但"你的真实 repository 里
 *       是否也还留着这几个档案、需不需要手动清掉"这件事本身要 CC
 *       自己的 repository/GAS 项目确认，Claude 无法代为操作，记入
 *       Backlog 供 CC 处理。
 *     - 00_Project_State.js 的 "Current Version: v1.4.0-dlp-defect-
 *       engine-phase1-8" 字串明显落后于目前实际进度（已完成
 *       ADR-P18/P19、真实 Import、真实 Consolidation migration），
 *       但下一个版本号该怎么定属于 CC 的命名判断，不是 Claude
 *       该自行决定的事，记入 Backlog。
 *
 *   本次系统性比对但判定"目前一致、无需修正"的部分（如实记录已查过，
 *   避免下次重复查一样的东西）：PropertyOS_DomainModel.md（Aggregate/
 *   Value Object/Invariant 表逐条比对 901/918 实际结构，一致）；
 *   00_Business_Rules.js BR-1 的 Obligation Category 清单（逐字比对
 *   PROPERTY_CONFIG.OBLIGATION_CATEGORIES，完全一致，17 项都对得上，
 *   顺序也一样）；DlpDefectEngine_VerticalSlice.md 的 DefectItem
 *   栏位清单（已在 ADR-P19 那一轮修正过，本次重新核实仍然一致）。
 *
 *   完整 Finding/Fix/Verification 明细见本次 housekeeping completion
 *   report（对话记录本身），此处只放会影响以后开发导航的摘要。
 *
 *   纯治理文件（.claspignore 排除，不推送到 GAS，仅供参考/审计）：
 *   00_ADR_Log.js / 00_Business_Rules.js / 00_File_Map.js（本文件）/
 *   00_Product_Backlog.js / 00_Project_Constitution.js /
 *   00_Project_State.js / 00_Review_History.js /
 *   DlpDefectEngine_VerticalSlice.md（新，Phase 0-8 完整设计记录）/
 *   DLP_Defect_Case_Engine_Phase0_Audit.md（Phase 0 历史稽核记录，
 *   DlpDefectEngine_VerticalSlice.md 自己引用它作为前身文件；先前
 *   没有独立列在这份清单里，2026-08-26 housekeeping 补上）/
 *   MANUAL_VERIFICATION_CHECKLIST.md / ObligationEngine_VerticalSlice.md /
 *   Phase11_RealDataOnboarding_Checklist.md（Phase 11 真实资料 onboarding
 *   操作清单，2026-08-26 housekeeping 补上）/
 *   PropertyAssetEngine_VerticalSlice.md / PropertyOS_DomainModel.md /
 *   README.md（2026-08-26 housekeeping 补上）
 *
 * Foundation 层（900-903）Runtime 已完成并批准（2026-07-19）。903 的
 * publishPropertyEvent_() 是 ADR-P07 的 Infrastructure Adapter，其
 * Logger 占位为刻意设计，非待办事项。
 *
 * 本文件不包含任何可执行逻辑，仅为治理文档。
 * ═══════════════════════════════════════════════════════════════════════
 */


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SYSTEM OVERVIEW
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
//   Property OS — AI Property Intelligence Platform
//   遵循 Universal Domain OS Blueprint：0 Governance / 1 Foundation /
//   2 Runtime / 3 Intelligence / 4 Integration / 5 Testing
//
//   号段规划（Reserved，非 Locked）：
//     0 Governance   — 00_（本地专属，非全局共用号段）
//     1 Foundation   — 900-909
//     2 Runtime      — 910-929
//     3 Intelligence — 930-939
//     4 Integration  — 940-949
//     5 Testing      — Node sandbox，独立于 GAS 文件编号


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 0. GOVERNANCE LAYER
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// 00_Project_Constitution
// Purpose: 项目宪法，架构/编码/命名/依赖/安全/AI 规则
// Status: Active (v0.2)

// 00_Project_State
// Purpose: 项目状态中心，进度/问题/技术债/下一步
// Status: Active (v0.2)

// 00_File_Map
// Purpose: 本文件，文件索引与职责说明
// Status: Active (v0.2)

// 00_ADR_Log
// Purpose: 正式架构决策记录（ADR-P01~P10），含 Decision Matrix
//   （Question/Options/Evaluation/Trade-off/Decision）
// Status: Active — v0.2，含 Review Approval 与 ADR-P06/P07 追认

// 00_Review_History
// Purpose: UEF 5 份 Mandatory Document 最后一份，之前一直缺。审核/
//   Audit 记录，独立于 00_Project_State 的日常 changelog。REVIEW-001
//   （Obligation Engine Production Readiness Audit）含 addendum
// Status: Active — 本次建立

// 00_Business_Rules
// Purpose: UEF §0.3 Conditional Document（trigger 已满足）。Obligation
//   Engine 的付款/循环/逾期/提醒/终止政策，与 Constitution 的结构性
//   架构内容分开维护
// Status: Active — 本次建立（Audit REVIEW-001 GAP-3 的修复）


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 1. FOUNDATION LAYER  [900-909]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// 900_PropertyConfig
// Purpose: 集中管理常量配置 — Obligation Category 列表（Mortgage/
//   Electricity/Water/Maintenance Fee/Sinking Fund/Quit Rent/
//   Assessment/Insurance/Internet/Subscription/Pest Control/Aircond
//   Service/Water Filter/Rental Collection/Lease Renewal/Warranty/
//   Defect Liability — ADR-P01 完整清单）、默认货币（Malaysia 场景，
//   默认 MYR）、默认 Reminder Offset 组合 (30/14/7/3/1/0/-1/-3/-7)、
//   Frequency 枚举
// Dependencies: 无
// Called By: 几乎所有 Runtime Engine
// Status: ✅ Runtime Complete — APPROVED (2026-07-19)

// 901_PropertySchema
// Purpose: 定义所有 Truth Layer 表结构（Entity 清单）。Obligation 相关
//   三表完整栏位已于 ObligationEngine_VerticalSlice.md §2 定案，其余
//   Entity 栏位仍待各自 Phase 的 Contract Design。也承载所有 Engine
//   共用的 Truth Layer 存取工具：propertyError_、日期序列化/解析
//   （toIsoDate_/toIsoDateTime_/parseIsoDate_/coerceToIsoDateString_）、
//   Row I/O（readRowAsObject_/objectToRowArray_/findRowIndexByFirstColumn_/
//   updateRowFields_）。ensureSheetSchema_ 新建表时会把 dateColumns
//   强制设为纯文字格式，防止 Sheets 把 ISO 日期字串誤判成 Date 序列值
//   而破坏 (ObligationID, EffectiveDue) 的字串比对幂等键
// Dependencies: 900_PropertyConfig
// Called By: 所有写入 Truth Layer 的 Engine
// Status: ✅ Runtime Complete — APPROVED (2026-07-19)（Obligation 三表；
//   其余 Entity 栏位待各自 Phase 细化）

// 902_PropertyIdentity
// Purpose: 统一 ID 产生与格式校验（PROP-/LOAN-/OBL-/OCC-/HIST-/TEN-/
//   LEASE-/DOC-/MAINT-/DEFECT-/RENO-/INS-/TAX-）
// Dependencies: 900_PropertyConfig
// Called By: 所有 Runtime Engine（建立新 Entity 时）
// Status: ✅ Runtime Complete — APPROVED (2026-07-19)

// 903_PropertyEventDefinitions
// Purpose: 事件类型目录，UPPER_SNAKE_CASE（v0.2 命名修正，见
//   Constitution §6）：OBLIGATION_CREATED, OBLIGATION_UPDATED,
//   OBLIGATION_CANCELLED, OBLIGATION_PAUSED, OBLIGATION_RESUMED,
//   PAYMENT_COMPLETED, PAYMENT_REVERSED（ADR-P06 compensating event），
//   REMINDER_REQUESTED, UTILITY_BILL_RECEIVED。完整 Payload/Producer/
//   Consumer 定义见 ObligationEngine_VerticalSlice.md §4。其他 Engine
//   的事件（Property/Loan/Document/...）待各自 Phase 加入，未预先列出
//   （避免 Speculative Design）。内含 publishPropertyEvent_()：
//   ADR-P07 Infrastructure Adapter，唯一允许知道 EventBus 实作的函式，
//   目前维持 Logger 占位，属刻意设计
// Dependencies: 900_PropertyConfig, 902_PropertyIdentity
// Called By: 所有 Engine（emit，一律经 publishPropertyEvent_）；
//   Intelligence 层（subscribe）；Integration Adapters（subscribe）
// Status: ✅ Runtime Complete — APPROVED (2026-07-19)

// 904_PropertyPermissions
// Purpose: Owner-based 存取控制；单一使用者假设，Owner 字段预留多人扩充
// Status: Deferred — 轻量规格

// 905_PropertyVersioning
// Purpose: Schema/Contract 版本追踪；Migration Strategy 见
//   ObligationEngine_VerticalSlice.md §12
// Status: Planned — Phase 1


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 2. RUNTIME LAYER — ENGINES  [910-929]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// 910_PropertyAssetEngine  ★ 核心新模块 — Runtime Complete
// Purpose: 管理房产主档。四个 Command（Create/Update/MarkSold/
//   ReverseSale）、State Machine 强制（Active⇄Sold，仅经
//   reversePropertySale 可逆，比照 912 的 Paid⇄Active）、单层 Lock、
//   ClientRequestID 幂等（Create）、结构化 Address VO（六栏位）+
//   formatAddress_ 衍生字段（不落库）、PropertyType 用 UPPER_SNAKE_CASE
//   （本系统唯一例外，CC 于 Review Approval 明确指示，见 00_ADR_Log.js）
// Dependencies: 901, 902, 903
// Called By: 912（propertyExists_ 现已真实接上，取代原本的 permissive
//   placeholder）, 922_DashboardEngine（尚未建）, 914_FinanceEngine
//   （尚未建）, 935_DecisionEngine（尚未建）, Telegram Layer（尚未建）
// Status: ✅ Runtime Complete (2026-07-29)。996_Tests_PropertyAssetEngine.js
//   （21 tests）+ 992 扩充（Event Contract/State Machine/formatAddress_，
//   19 tests）逻辑已自我检查全数通过，过程中真的抓到一个 bug：
//   reversePropertySale 原本误呼叫了通用的 assertPropertyTransition_
//   ('Sold','Active')，但 PROPERTY_TRANSITIONS_ 故意没有 'Sold' 这个
//   key（比照 912 的 OCCURRENCE_TRANSITIONS_ 不放 'Paid' 的原因——
//   唯一允许离开 Sold 的路径就是这个 Command 自己的明确检查，不是
//   通用 Map），所以每次呼叫都会抛错。已修正：拿掉那行呼叫，靠原本
//   就有的 PROPERTY_NOT_SOLD 检查即可。★ 2026-08-26 housekeeping
//   修正：这条目原本还写"待 CC 对真实 GAS 项目实际跑一次确认（TECH
//   DEBT）"，但 00_Project_State.js 已经记录"910_PropertyAssetEngine
//   Runtime 完成并批准，真实 GAS 确认通过（不再是 IN PROGRESS）"——
//   真机确认其实已经做完，这份 File Map 当时没有同步更新，本次比对
//   后发现並修正，不是这次才验证通过。

// 911_DocumentEngine  ★ Runtime Complete (minimal scope)
// Purpose: Evidence 附件——DLP Defect Case Vertical Slice 需要的最小
//   范围（attachEvidence/getEvidence/listEvidenceForCase/
//   listEvidenceForDefect），不是原先设想的完整 Document Library（PII
//   文件、全文检索等仍未做，未来若真的要做完整版，从这里长出去，
//   不需要重新命名或换 ID 前缀）。Drive Adapter 隔离在
//   saveEvidenceFile_ 一处（ADR-P07/P11），资料夹结构 Property OS
//   Evidence/<CaseID>/<fileName>。
// Dependencies: 901, 902, 903, 918（caseExists_/defectItemExists_/
//   getDefectItem/appendCaseTimelineEntry_ — 单向依赖，918 不反过来
//   呼叫 911）
// Called By: 918（透过 UI/Console 层协同使用，非直接函式呼叫）,
//   930_PropertyKnowledgeGraph（Future）
// Status: ✅ Runtime Complete，最小范围 (2026-08-17, Phase 5)。真实
//   Drive 上部署确认（真实资料夹/文件 URL，见 MANUAL_VERIFICATION_
//   CHECKLIST.md）。原定的完整 Document Library（PII、全文检索）仍是
//   Planned，未开始。

// 912_ObligationEngine  ★ 核心新模块 — Runtime Complete
// Purpose: ADR-P01 之 Single Source of Truth 实作。七个 Command
//   （Create/Update/RecordPayment/Cancel/Pause/Resume/Reverse）、State
//   Machine 强制、单层 Lock、ClientRequestID 幂等（Create/Update）、
//   OccurrenceID 天然幂等（RecordPayment）、AI Query（Upcoming/Overdue）
//   全部落地，严格依照已批准的 Vertical Slice
// Dependencies: 901, 902, 903, 913（scheduleNextOccurrence_/
//   buildReminderRequest_）
// Called By: 944_PropertyTelegramCommands（尚未建），922_DashboardEngine
//   （尚未建），914_FinanceEngine（订阅 PAYMENT_COMPLETED，尚未建）
// Status: ✅ Runtime Complete (2026-07-19)。2026-07-29: propertyExists_
//   现由 910_PropertyAssetEngine 提供真实实作（原本的 permissive
//   placeholder已移除——ADR-P07 Adapter 模式的承诺兑现）。
//   2026-07-29 新增 logPartialFailure_：create/record/reverse Payment
//   在 Truth 写入之后的步骤失败时大声记录（UEF v1.6 §2/D9），不假装
//   原子性——Sheets 没有多语句事务，这是平台事实不是本文件的选择

// 913_ObligationScheduler  ★ 核心新模块 — Runtime Complete
// Purpose: Frequency-aware NextDue 计算（含月末 clamp，避免 1/31 +1月
//   溢出到 3 月）；Overdue 全为 Derived State，查询时即时算，不写入、
//   不排程；REMINDER_REQUESTED 建构与发布（经 903 的 Adapter）
// Dependencies: 912_ObligationEngine（createOccurrence_,
//   transitionRuleToCompleted_ — 直接呼叫，作为"订阅"PAYMENT_COMPLETED
//   的暂代方案，见档头说明）, 941_ReminderIntegrationAdapter（尚未建）
// Called By: 912_ObligationEngine（recordPayment, createObligation）
// Status: ✅ Runtime Complete (2026-07-19)
// ⚠ REMINDER_REQUESTED 的 payload 格式是需求规格；ReminderConnector
//   实际 API 是否满足仍待核实（00_Project_State TECH DEBT #1，未阻塞
//   本次 Runtime 完成——比照 ADR-P07 精神，Domain 逻辑先写完）

// 914_FinanceEngine
// Purpose: Ledger 与 Cashflow 计算（基础版）。ADR-P01 明文禁止维护
//   任何 Due Date/Reminder Schedule/Payment Schedule，只能订阅
//   PAYMENT_COMPLETED/PAYMENT_REVERSED/PROPERTY_SOLD/
//   PROPERTY_SALE_REVERSED，镜像写入不可变的 Ledger（ADR-P06/P10 applied）
// Dependencies: 901, 902, 903；订阅 912/910 事件（非直接依赖，
//   ADR-P12——EventBus 是占位 Adapter，Architecture 不因此妥协）
// Called By: 922_DashboardEngine（尚未建）, 932_CashflowForecastEngine
//   （尚未建，Phase 4）, 942_InvestmentIntegrationAdapter（尚未建）
// Status: ⏳ Vertical Slice 完成（FinanceEngine_VerticalSlice.md），
//   等待 Review Approval，未写 Runtime。两项待确认：(1) Category
//   继承是否透过 getObligation() 唯读查询，还是要求 912 的
//   PAYMENT_COMPLETED payload 直接带 category 栏位；(2) PROPERTY_
//   SALE_REVERSED 的补偿分录用 Expense 还是需要独立语义。

// 915_MortgageEngine
// Purpose: Mortgage Calculator — Amortization/Refinancing/Comparison/
//   Rate Simulation。与 912 的关系：Mortgage 类别 Obligation 之金额
//   来源参考；Mortgage 完全摊还时可触发 ObligationRule 之
//   Active→Completed（自然到期，非 Cancelled，见 Vertical Slice §9）
// Dependencies: 901, 902, 910
// Called By: 922_DashboardEngine, 935_DecisionEngine
// Status: Planned — Phase 2

// 916_RentalEngine
// Purpose: Tenant/Lease 生命周期
// Dependencies: 901, 902, 903, 910
// Called By: 922_DashboardEngine, 931_ObligationAnomalyDetector, 941
// Status: Planned — Phase 2

// 917_MaintenanceEngine
// Purpose: 维修历史，供 AI 回答总成本/Warranty 到期/重复维修分析
// Dependencies: 901, 902, 903, 910
// Status: Planned — Phase 2

// 918_DefectEngine (VP/Defect)  ★ 核心新模块 — Runtime Complete (Phase 1-8)
// Purpose: DLP Defect Case & Rectification Tracking——完整 Case→
//   DefectItem→DailyProgressCheck/Correspondence/RectificationEvent/
//   SecondaryDamage→PropertyCaseTimeline 生命周期。ADR-P15 记录了不拆
//   通用 Case Engine 的决定：PropertyCase.CaseType 目前只有 'DLP'，
//   留扩展口但不预先做 Speculative Design。DeveloperStatus 与
//   OwnerVerificationStatus 严格独立（ADR-P15），DefectItem.Status
//   透过 deriveDefectItemStatus_ 从两者衍生（Lazy Computation），
//   Closed 边界只有 closeDefectItem/reopenDefectItem 能跨越。
// Dependencies: 901, 902, 903, 910（propertyExists_/getProperty，
//   Runtime→Runtime，比照 912 依赖 910 的既有模式）
// Called By: 911（caseExists_/defectItemExists_/getDefectItem/
//   appendCaseTimelineEntry_ 反向被呼叫）, 922（getCaseTimeline 透过
//   propertyCaseTimelineSheet_ 私有函式直接呼叫，比照 922 原本呼叫
//   912 私有函式的既有模式）
// Status: ✅ Runtime Complete，Phase 1-8 (2026-08-17)。真实 GAS 部署
//   逐 Phase 确认（细节见 00_Project_State.js CHANGELOG、
//   DlpDefectEngine_VerticalSlice.md）。Phase 9-11（Mobile Web
//   Console、Sidebar DLP Tab、997_Tests_DefectEngine.js 正式 GAS-
//   native 测试）未开始。已知 Domain Model limitation（非 bug，
//   ADR-P15）：OwnerVerificationStatus 目前是 DefectItem 上的单一
//   栏位，未来若要正确处理"Failed 之后 Developer 重新宣称完成"这种
//   情况，需要 Repair Cycle / Verification Cycle 概念，这次没做。

// 919_RenovationEngine
// Purpose: Quotation/Budget/Timeline/Progress
// Status: Planned — Phase 3

// 920_InsuranceEngine
// Purpose: MRTA/MLTA/Fire/House Insurance
// Status: Planned — Phase 3

// 921_TaxEngine
// Purpose: RPGT/Rental Income Tax/Tax Summary（输出须标注非专业税务意见）
// Status: Planned — Phase 3

// 922_DashboardAdapter  ★ Runtime Complete（文件名与原规划的
//   "922_DashboardEngine" 不同——ADR-P14 实际建立时定名
//   922_DashboardAdapter.js，purpose 跟这里原本的规划相符，只是
//   filename 当时没同步回这份 File Map，一并订正）
// Purpose: 纯 Projection/Query 组合层，不拥有任何 Truth 表
// Dependencies: 910, 912, 918（getDlpCaseDashboard 等 DLP 新增部分）
// Called By: 945/946 Operator Console
// Status: ✅ Runtime Complete。Obligation 相关部分 (ADR-P14,
//   2026-07-29)；DLP Dashboard 部分 (Phase 8, 2026-08-17) —
//   getDlpCaseDashboard/getCaseTimeline/listDefectItemsForDashboard/
//   enrichPropertyCaseForDisplay_/enrichDefectForDisplay_/
//   isRectificationEventUpcoming_。★ buildCaseOverviewForMobile_
//   (2026-08-21/22，单一 pass 版，947 的 dlp_getCaseOverview 用它) 当时
//   没同步补进这份清单，本次一并补上——它本身早就是 Runtime Complete，
//   不是这次新变更。★ 2026-08-31：enrichDefectForDisplay_ 补
//   subCategory/remark（Sidebar DLP Tab Phase 1 vertical slice
//   1，00_Review_History.js REVIEW-008）——listDefectItemsForDashboard
//   组合使用这个函式，因此自动一起带出这两个新栏位，未额外改动。
//   ★ 2026-09-01（vertical slice 2 + Overview 真机 crash 修复，
//   00_Review_History.js REVIEW-009）：新增
//   buildDefectDetailForSidebar_（Contract §18 的 Detail-page 聚合
//   函式）+ 4 个 enrich 函式（RectificationEvent/Evidence/
//   SecondaryDamage/Correspondence）。同时新增
//   coerceIsoDateTimeForDisplay_ 防御工具（对齐 901
//   coerceToIsoDateString_ 的同一类防御，但这个留在 922、不放进
//   901——精度也不同，前者是完整 datetime、后者是纯日期），修好
//   getCaseTimeline 排序对非字符串 OccurredAt 直接
//   throw 的真机 crash（CC 真机测试 Case Overview 空白，定位到这里）。
//   914/915/916/917 尚未建，届时若要加对应 Dashboard 数据，比照同一
//   组合模式扩充，不需要重新设计。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 3. INTELLIGENCE LAYER  [930-939]  — 全部输出 advisory-only
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// 930_PropertyKnowledgeGraph
// Purpose: 跨 Entity 关联索引，由 EventBus 事件建立，本身非 Truth
// Status: Planned — Phase 4

// 931_ObligationAnomalyDetector
// Purpose: 费用异常/利率变化/保险到期/欠缴/超均值/现金流为负 侦测；
//   Query Interface 见 ObligationEngine_VerticalSlice.md §8
// Dependencies: 912_ObligationEngine, 914_FinanceEngine, 916_RentalEngine
// Status: Planned — Phase 2（优先级较高）

// 932_CashflowForecastEngine
// Purpose: 未来一年现金流预测
// Dependencies: 914_FinanceEngine, 912_ObligationEngine
// Status: Planned — Phase 4

// 933_InvestmentScoringEngine
// Purpose: Investment/Risk/Growth Score
// Status: Planned — Phase 4

// 934_MarketAnalyticsEngine
// Purpose: 市场/成交/租金/Developer/Location 分析
// Status: Deferred — Phase 5

// 935_DecisionEngine
// Purpose: Should I Buy/Sell/Rent/Refinance/Renovate；纯 advisory
// Dependencies: 930, 931, 932, 933, 934, 914, 915
// Status: Deferred — Phase 4


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 4. INTEGRATION LAYER  [940-949]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// 940_PropertyConnector
// Purpose: Property OS 对外统一入口（Standard Connector Interface）
// Dependencies: 922_DashboardEngine
// Called By: ConnectorRegistry；Investment OS
// Status: Planned — Phase 1（最小可用版本）

// 941_ReminderIntegrationAdapter
// Purpose: 只 Publish REMINDER_REQUESTED Event 予 ReminderConnector
//   （ADR-P02）；不建立 Trigger；不追踪 Reminder 送达状态
// Dependencies: ReminderConnector（外部）
// Status: Planned — Phase 1
// ⚠ 依赖风险：见 Constitution §8 与 913 条目

// 942_InvestmentIntegrationAdapter
// Purpose: 提供 Property ROI/Cashflow/Debt Ratio 予 Investment OS
// Dependencies: InvestmentConnector（是否已存在待核实）
// Status: Deferred — Phase 4

// 943_NewsIntegrationAdapter
// Purpose: 订阅 Interest Rate/OPR/Property Policy 等新闻
// Dependencies: NewsConnector（News OS 可能尚未建置）
// Status: Deferred

// 944_PropertyTelegramCommands
// Purpose: /property_due [week|month]、/property_paid <category>
//   <args> 指令解析与转发
// Dependencies: 912_ObligationEngine, 922_DashboardAdapter
// Called By: Telegram Layer（共用路由器）
// Status: Planned — Phase 1

// ⚠ 号码冲突记录（2026-08-17 发现，订正；2026-08-19 更新）：945/946
// 原本规划给下面两个 Deferred 概念，但 Operator Console（945_
// OperatorConsole.html / 946_OperatorConsoleServer.js）实际建立时占用
// 了这两个号，当时没有同步回这份 File Map。这两个 Deferred 概念本身
// 没有变，等真的要做时需要挑其他空号——2026-08-19 后 947/948 也已被
// DLP Mobile Console 占用（见下方），候选号段因此变成 949+ 或 94x 里
// 其他未占用的，不是现在的待办，先如实记录冲突存在。

// 945_DocumentImportAdapter（号码待重新分配，见上方冲突说明；
//   947/948 已被占用，候选号段是 949+）
// Purpose: [ADR-P05] 未来 OCR/Email/PDF 账单摄入，统一转换为
//   UTILITY_BILL_RECEIVED 事件 → 912 消费转为 OBLIGATION_UPDATED；
//   不主动 Poll 任何外部系统（Manual Input/Email OCR/PDF OCR/API/
//   Import 皆汇入同一事件管道）
// Status: Deferred — Phase 5（预留接口，不实作）

// 946_BankReconciliationAdapter（号码待重新分配，见上方冲突说明；
//   947/948 已被占用，候选号段是 949+）
// Purpose: [ADR-P05] 未来银行对账，同样汇入 UTILITY_BILL_RECEIVED
//   管道，不主动 Poll
// Status: Deferred — Phase 5

// 945_OperatorConsole.html + 946_OperatorConsoleServer.js
//   ★ 实际部署的 945/946（Runtime Complete）
// Purpose: HtmlService Sidebar，Tab 式单页应用，透过
//   google.script.run.withSuccessHandler() 呼叫 946 的 console_* thin
//   wrapper（console_wrap_ 统一 try/catch），业务逻辑 0% 留在这两个
//   文件里，全部转发给 Domain 层（910/912/918/922）。ADR-P14 建立。
// Dependencies: 910, 912, 918（非直接——透过 947，2026-08-31 DLP Tab
//   vertical slice 1 起才成立，945 本身从不直接呼叫 918）, 922, 947
//   （新，2026-08-31，DLP Tab 专用 wrapper，见下方 947 条目）
// Status: ✅ Runtime Complete，实战使用中 (2026-07-29 起)——四个既有
//   Tab（Dashboard/Add Bill/Properties/History）不受下面这段影响。DLP
//   专属 Tab（跟 947/948 的 Mobile Console 是两个不同 UI Surface，各自
//   独立设计——DlpMobileConsole_UIContract.md §0 当时明确排除在那次
//   范围外）设计已于 2026-08-31 定案（DlpSidebarTab_UIContract.md，
//   00_Review_History.js REVIEW-007、00_Product_Backlog.js BL-7）。
//   ★ 2026-08-31（同日稍晚）：Phase 1 的 vertical slice 1（Case
//   Overview / Defect List / Defect Detail / Update Developer Status /
//   Record Owner Verification）已实作——新第 5 个 "DLP" Tab，
//   Overview/Defects 子导航 + Detail 双动作表单，走 947 的新 dlp_*
//   wrapper（不走 946，如 ADR-P20 既定架构，946 本身这次确认零改动）。
//   ★ 2026-09-01：CC 对 slice 1 做了真机测试——Defect List/Detail/两个
//   写入动作全部正常；Case Overview 空白，定位到 922 的
//   getCaseTimeline 排序 bug（详见 947/948 条目、
//   00_Review_History.js REVIEW-009），已修复但这个修复本身还没真机
//   验证。同一轮也完成了 vertical slice 2（Rectification
//   Event/Evidence/Secondary Damage/Correspondence）：新第 3 个子导航
//   （Correspondence，唯读），Defect Detail 新增三个区块（各自一个
//   既有记录列表 + 一个 details/summary 收合式 Add 表单），
//   renderDlpDefectDetail 因应 947 回传形状升级而整个改写（raw
//   PascalCase → camelCase bundle）。BL-7 状态为
//   IMPLEMENTATION COMPLETE（本地层面），真机验证是 CC 下一步。

// 947_DlpConsoleServer.js + 948_MobileConsole.html   ★ 新 (2026-08-19)，
//   ★ 2026-08-31 起共用 Glue Point 从"架构决定"变成"实际运作中"
//   （ADR-P20，见下方）
// Purpose: DLP Mobile Console（Phase 9/10 合并交付——原规划是两个
//   Phase，因为 Daily Check 变成整个落地页而非加在通用 Shell 之后的
//   功能，合并成一次交付）。947 是 doGet() Web App 入口 + dlp_* thin
//   wrapper（dlp_wrap_ 统一 try/catch，跟 946 的 console_wrap_ 同一
//   纪律），948 是独立页面本身（Daily Check 表单 + Saved 状态 + 拍照
//   Evidence + 唯读 Case Overview）。947 设计上预留给未来 Sidebar DLP
//   Tab 共用，避免两个 UI Surface 各自重复一套 wrapper——★ 2026-08-31
//   (b)：这个预留正式兑现，945 的新 DLP Tab（vertical slice 1）已经在
//   用 947 的新 dlp_* wrapper。完整设计过程/理由/未来变更边界见独立
//   文件 DlpMobileConsole_UIContract.md（Mobile 原始设计）+
//   DlpSidebarTab_UIContract.md（Sidebar 设计，2026-08-31）。
// Dependencies: 900（ACTIVE_DLP_CASE_ID/OPERATOR_NAME，MVP
//   Configuration，非 Domain——见 Contract §9.1/§9.2）, 910
//   （getProperty）, 918（getPropertyCase/logDailyProgressCheck；★
//   2026-08-31 (b) 新增 getDefectItem/recordDeveloperStatus/
//   recordOwnerVerification；★ 2026-09-01 新增
//   logRectificationEvent/listRectificationEventsForDefect/
//   logSecondaryDamage/listSecondaryDamageForDefect/
//   listCorrespondenceForCase，Sidebar DLP Tab 新 dlp_* wrapper 使用）,
//   911（attachEvidence；★ 2026-09-01 新增 listEvidenceForDefect）, 922
//   （buildCaseOverviewForMobile_ ——★ 2026-08-30 修正：这行原本列的是
//   getDlpCaseDashboard/listDefectItemsForDashboard/getCaseTimeline，
//   但 dlp_getCaseOverview 实际呼叫的是 buildCaseOverviewForMobile_，
//   2026-08-21/22 N+1 修复时就已经换掉，这份 File Map 当时没跟着更新，
//   当次顺手修正；★ 2026-08-31 (b) 新增的 Sidebar 专属
//   dlp_getSidebarCaseDashboard/dlp_listSidebarDefects 两个 wrapper 则
//   确实呼叫回 getDlpCaseDashboard/listDefectItemsForDashboard 本身
//   ——两条依赖因此都准确，不是互相矛盾；★ 2026-09-01 新增
//   buildDefectDetailForSidebar_，dlp_getSidebarDefectDetail 从直接呼叫
//   getDefectItem 升级为呼叫这个新聚合函式）
// Called By: doGet()（Mobile Web App 入口）+ ★ 2026-08-31 (b) 起，
//   945_OperatorConsole.html（透过 google.script.run，DLP Tab 专用的
//   6 个新 dlp_* wrapper，★ 2026-09-01 再新增 4 个）——947 不再只有
//   doGet() 一个呼叫者，这正是 ADR-P20 的设计意图
// Status: ✅ PRODUCTION-READY（Contract §11 的 11 步真机验证 Gate 全部
//   通过，2026-08-22，见 00_Review_History.js REVIEW-002 Disposition：
//   "GO。DLP Defect Engine Phase 9/10（Mobile Web Console）
//   PRODUCTION-READY"）。★ 2026-08-26 housekeeping 修正：这条目原本
//   还停在"⏳ RUNTIME CODE COMPLETE, NOT PRODUCTION-READY...零真机
//   测试"，但真机验证其实已经做完、REVIEW-002 也已经批准，这份
//   File Map 当时没有同步更新——本次比对 00_Review_History.js 与
//   00_Project_State.js 后发现并修正，不是这次才验证通过。范围仅限
//   Phase 9/10 这个子系统，不代表整个 Property OS 项目已
//   Production-Ready（同一份区分，见本文件页首 PROJECT STATUS 说明）。
//   ★ 2026-08-30 新增：buildCaseOverviewForMobile_ 回传的每个 defect
//   物件补上 itemId/subCategory/remark，948 的 renderOverview_ 卡片
//   跟着显示。CC 已部署真实 GAS、初步确认无异常（"暂时无误"，非正式
//   逐项真机验证）。完整记录见 00_Review_History.js REVIEW-006。
//   ★★★ 2026-09-06~09 大幅扩充（BL-13~BL-17，完整脉络见
//   DlpMobileConsole_UIContract.md §12 Amendment、ADR-P25、ADR-P26，
//   不在此重复展开）：918 的 recordDeveloperStatus/recordOwnerVerification
//   两者新增 clientRequestId（ADR-P25），947 对应两个 wrapper 转传，
//   同时补上 dlp_addRectificationEvent/dlp_attachDefectEvidence 原本
//   遗漏的转传；947 新增 dlp_getMobileDefectDetail（重用既有
//   buildDefectDetailForSidebar_，922 未新增函式）；948 从 2 个 view
//   （Daily Check + 唯读 Overview）扩充成 3 个 view，新增 Defect Detail
//   （只读）、Owner Verification 写入、Developer Status 写入、Defect
//   Search + A-Z/Z-A Sort（纯 client-side，零新增 backend API）。
//   Defect Detail/Owner Verification/Developer Status 三者
//   ★ 已真机验证（2026-09-08/09）；Search/Sort 本地测试过、真机验证
//   PENDING。M4（Rectification Event）/M5（Evidence 上传）尚未开始。
//   Secondary Damage/Correspondence/Close-Reopen-CloseCase 依然完全
//   不曝光给 Mobile。新建 local_precheck_test_947.js（947 首个本地
//   测试，22 项）与 local_precheck_test_948_search.js（948 首个、也是
//   首个真的可执行而非纯静态核对的本地测试，29 项）——两者说明见本文件
//   下方 test 档案区块。.claspignore 同期补上
//   `local_precheck_test_*.js` wildcard，修正现役 local test 档案原本
//   未被排除、可能被整批 clasp push 带进真实专案的部署安全缺口。
//   PRODUCTION-READY 状态维持不变——这是既有 PRODUCTION-READY 子系统上
//   的小幅追加，不是重新走一次 Gate。
//   ★ 2026-08-31 (b) 新增：6 个 dlp_* Sidebar wrapper
//   （dlp_getSidebarCaseDashboard/dlp_listSidebarDefects/
//   dlp_getSidebarDefectDetail/dlp_recordDeveloperStatus/
//   dlp_recordOwnerVerification/dlp_getSidebarFormOptions，详见 945/946
//   条目、00_Review_History.js REVIEW-008）。这部分本身尚未部署、尚未
//   真机验证——上面这段 PRODUCTION-READY 认证范围仅限原有的 Mobile
//   Console 4 个 dlp_* 函式（dlp_getMobileBootstrap/dlp_logDailyCheck/
//   dlp_attachEvidence/dlp_getCaseOverview），不自动延伸覆盖这次新增的
//   6 个，如实标注避免混淆。
//   ★ 2026-09-01：CC 对上面这 6 个 wrapper 做了真机测试——
//   dlp_listSidebarDefects/dlp_getSidebarDefectDetail/
//   dlp_recordDeveloperStatus/dlp_recordOwnerVerification 确认正常；
//   dlp_getSidebarCaseDashboard 报空白，定位到 922 的 getCaseTimeline
//   排序对非字符串 OccurredAt 直接 throw（真机上某个 Sheet
//   儲存格被 Sheets 自动转成原生 Date 物件所致），已修复——同时该
//   wrapper 也补上跟 dlp_getCaseOverview 同款的 JSON.stringify（此前
//   没加是因为当时判断 945 既有 4 个 Tab 已证明"嵌套物件不需要
//   stringify"，真机结果证明这个判断对更深/更複杂的物件不成立，本次
//   订正）。完整记录见 00_Review_History.js REVIEW-009。这个修复本身
//   还没真机验证。新增 4 个 dlp_* wrapper（dlp_addRectificationEvent/
//   dlp_attachDefectEvidence/dlp_addSecondaryDamage/
//   dlp_listSidebarCorrespondence，vertical slice 2）同样不在
//   PRODUCTION-READY 范围内，零真机验证。
//   ★ 2026-09-01（同日稍晚）：CC 对以上全部 10 个 Sidebar dlp_*
//   wrapper（6 个 slice 1 + 4 个 slice 2，含 Overview crash 修复后的
//   dlp_getSidebarCaseDashboard）做了真机验证，回报无问题（一般性
//   确认，非 REVIEW-002 那种正式逐项 Gate）。见
//   00_Review_History.js REVIEW-009 Addendum。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 5. TESTING LAYER
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
//   ★ 2026-07-29：CC 明确指示 Property OS 只在 Google Apps Script 用，
//   所有代码都要是 GAS 能跑的——原本的 property-os-tests/（Node 本地
//   沙箱，用 require/module.exports/vm，从来就不是拿来贴进 Apps
//   Script 编辑器的）已从本项目移除，不再是 Property OS 的一部分。
//   之前那 108 个测试涵盖的东西，已经全部搬进下面这几个纯 GAS-native
//   文件，没有遗漏——搬迁细节见 00_Project_State.js changelog。
//
//   全部都是纯 Apps Script 语法（无 require/module.exports/process/
//   __dirname），跟 900-903/912-913 贴在同一个 GAS 专案里，靠 GAS
//   本身的共用全域作用域互相调用，不需要任何 import 机制。
//
//   990_TestKit
//   Purpose: GAS-native assert/report utility
//   Dependencies: 无
//   Status: ✅ Built (2026-07-29)
//
//   991_Tests_ObligationEngine
//   Purpose: 真实 SpreadsheetApp/LockService/CacheService——9 个测试，
//     聚焦在只有真实环境才能验证的部分：真实日期防护、真实 freeze
//     header、真实 Lock/Cache、端到端 create→pay 真实转到下一期。
//     assertRunningInTestSpreadsheet_ 安全防呆（spreadsheet 名字须含
//     "TEST"）、cleanupTestData_ 级联清理，两者定义于本文件，供
//     992-995 共用（同一 GAS 专案共用全域作用域）
//   Dependencies: 900-903, 912-913, 990
//   Status: ✅ 已在 CC 真实 GAS 专用测试 spreadsheet 跑过，9/9 通过
//
//   992_Tests_PureLogic  ← 新增 2026-07-29
//   Purpose: 纯函数测试，零 Sheet 写入，可安全在任何环境跑。涵盖 ID
//     产生格式、日期工具、addFrequencyToDate_ 全部频率类型（含月底
//     闰年 clamp）、Overdue 判定、State Machine guard、9 种 Event
//     Contract 的必填栏位系统性检查
//   Dependencies: 900-903, 912-913
//   Status: ✅ 75 tests（56 原有 + 19 于 910 完成后新增：4 种 Property
//     Event Contract、assertPropertyTransition_、formatAddress_），
//     逻辑已用私有 Node shim 自我检查（75/75），
//     待 CC 对真实 GAS 项目实际跑一次
//
//   993_Tests_FullLifecycle  ← 新增 2026-07-29
//   Purpose: 真实 Sheets 上的完整 Command 生命周期——7 个 Command 的
//     validation/success/idempotency、cancel/pause/resume、
//     reversePayment 全周期、AI Query 过滤
//   Dependencies: 900-903, 912-913, 990, 991（共用 assertRunning
//     InTestSpreadsheet_/testPropertyId_/cleanupTestData_）
//   Status: ✅ 27 tests，逻辑已自我检查（27/27），待 CC 实跑
//
//   994_Tests_ExtendedPlatform  ← 新增 2026-07-29
//   Purpose: Replay（多步骤真实序列）、Retry、Duplicate Command、
//     ★ Partial Failure（真实故障注入，在真实 GAS 里覆写全域函式，
//     手法跟之前 Node 版本一样，因为 GAS 本身也是共用全域作用域）、
//     Lock 释放、Reminder Contract、Migration 机制检查（验证
//     OBLIGATION_CATEGORIES 确实是 frozen，新增类别必须走真实的
//     源码编辑+部署，不是 runtime 能改的）
//   Dependencies: 900-903, 912-913, 990, 991
//   Status: ✅ 7 tests，逻辑已自我检查（7/7），待 CC 实跑
//
//   995_RunAllTests  ← 新增 2026-07-29
//   Purpose: 依序跑完 991-994、996，输出汇总。runAllPropertyOSTests()
//   Dependencies: 990-994, 996
//   Status: ✅ 汇总已自我检查：139/139（56+19+9+27+7+21，见下方明细）
//     全数通过
//
//   996_Tests_PropertyAssetEngine  ← 新增 2026-07-29（910 Runtime 完成）
//   Purpose: 910 四个 Command 的 validation/success/state transition，
//     含 propertyExists_/createObligation 的跨 Engine 整合确认
//   Dependencies: 900-903, 910, 990, 991（共用安全防呆/cleanupTestData_）
//   Status: ✅ 21 tests，逻辑已自我检查（21/21，过程中抓到并修正一个
//     真的 bug——见 910 条目），待 CC 实跑
//
//   MANUAL_VERIFICATION_CHECKLIST.md（仍保留，独立于本项目 GAS 文件
//   之外，纯文档）—— 即使 99 个 GAS-native 测试都通过，仍有几项
//   （真实并发下的 Lock 竞争、CacheService 真实 1 小时 TTL 到期、
//   GAS 6 分钟执行上限）无法在单次测试跑里验证，如实保留待办，不
//   因为测试数字好看就假装已核实。
//
//   ★ §5a LOCAL PRECHECK TESTING CONVENTION（2026-08-26 housekeeping
//   新增条目——这个惯例本身从 Phase 11 一开始就在用，只是先前从没有
//   在 File Map 里正式记录过）：
//
//   跟上面 990-996（GAS-native，贴进真实 GAS 项目跑）是两回事，也跟
//   下面 §5b 提到、已确认死掉的旧 Node 沙箱（require('../shim/...')
//   那批）不是同一套——这是目前唯一现役的本地 Node 测试惯例，每次
//   改动 Runtime/Schema 前后都拿来快速验证用，不推送到 GAS
//   （.claspignore 排除）。
//
//   GasShim.js — 共用的 SpreadsheetApp/LockService/CacheService/
//     Logger 等 GAS 全域物件的最小 Node mock，外加
//     loadPropertyOSContext(dir, files) 把指定的 .js 档案在一个 vm
//     context 里跑起来，模拟 GAS 共用全域作用域。目前 mock 的方法：
//     getRange/getValues/setValues/setNumberFormat/getLastRow/
//     getLastColumn/insertSheet/getSheetByName/flush/setFontWeight/
//     autoResizeColumns（後四个明确注解为 test infrastructure，非
//     domain 逻辑）。没有 mock PropertiesService——这是
//     local_precheck_test_911.js 会跑不动的已知、非本次造成的原因。
//   Dependencies: 无（Node 内建 vm/require 即可）
//   Called By: 下面全部 local_precheck_test_*.js
//   Status: ✅ 现役共用基础设施
//
//   local_precheck_test_918.js / _922.js / _911.js — 分别对应
//     918_DefectEngine/922_DashboardAdapter/911_DocumentEngine 的本地
//     回归测试，各自档案内自带 pass/fail 计数与 check() helper（不
//     共用一个中央 TestKit——每个档案独立自足）。跑法：
//     node local_precheck_test_918.js。
//   local_precheck_test_phase11_schema_migration.js — Phase 11
//     跨档案契约测试（901→918→ONETIME_Phase11_DefectImporter.js 的
//     schema round-trip）。ADR-P18 建立，ADR-P19 时全面重写以反映
//     OriginalReference 合并、19 栏 schema、新 Category enum。
//   local_precheck_test_phase11_defectitem_reorder_migration.js —
//     专测 ADR-P18 的 reorder migration script。★ 该 migration 已对
//     真实资料执行成功、任务已完成，此测试自 2026-08-26 起因为 901
//     的 live schema 又往前走了一步（ADR-P19）而无法在目前 codebase
//     状态下完整重跑——已在该档案自己的标头详细加注原因与真实资料
//     无风险的理由，逻辑本体刻意不动，当历史记录保留。
//   local_precheck_test_phase11_schema_consolidation_migration.js —
//     专测 ADR-P19 的 consolidation migration script（新建，
//     2026-08-26）：涵盖零笔资料、三种 ItemID/OriginalReference 合并
//     情境、冲突侦测中止、非法 Category 中止、idempotency、未知表头
//     拒绝、sheet 不存在。
//   Status: ✅ 全部现役，2026-08-26 housekeeping 时重新逐一执行确认：
//     918 144/144、922 37/37、911 因 PropertiesService gap 无法执行
//     （已知、非本次造成）、phase11_schema_migration 71/71、
//     phase11_schema_consolidation_migration 38/38 全通过；
//     phase11_defectitem_reorder_migration 见上方说明。
//
//   local_precheck_test_947.js（新增，2026-09-06）—— 947_DlpConsoleServer.js
//     从建立以来第一个本地测试档案。只测 Mobile Field Console
//     Retry-Safety Foundation slice新增的 Bridge 层 clientRequestId
//     转传行为本身（Developer Status/Owner Verification/Rectification
//     Event 三者走真实呼叫；Evidence 用既有 driveFileId 捷径避开 911
//     那个已知 PropertiesService gap），不重测 918 已经测过的
//     idempotency 机制本体。跑法：node local_precheck_test_947.js。
//   local_precheck_test_948_search.js（新增，2026-09-09）——
//     948_MobileConsole.html 第一个本地测试档案（也是第一个真的可执行、
//     不是纯静态核对的 948 测试）。只测 Defect Search/Sort（BL-17）
//     的三个纯函式（defectMatchesQuery_/compareDefectsByItemId_/
//     filterAndSortDefects_，刻意不碰 DOM）——把 948 的 <script> 内容
//     读进一个只 stub 了 document.addEventListener 的最小 VM context
//     直接呼叫。948 其余 DOM 相关行为（M1-M3 的 render/setup 函式
//     本体）不在这个档案的测试范围内，沿用既有的静态 grep 核对方式。
//     跑法：node local_precheck_test_948_search.js。
//   2026-09-06 重新执行全部现役 local_precheck_test_*.js 确认目前实际
//     数字（上面 2026-08-26 那行数字已经过时，不重写历史记录，只在此
//     新增一行如实反映现况）：918 163/163（含本次新增 16 项
//     idempotency 断言）、947 13/13（新档案）、922 67/67、911 维持跟
//     2026-08-26 时一样的既有 PropertiesService gap、
//     phase11_schema_migration 71/71、
//     phase11_schema_consolidation_migration 38/38 不变、
//     phase11_defectitem_reorder_migration 维持既有失败状态（★
//     该档案本来就因 901 schema 演进而无法完整重跑，跟本次改动无关，
//     未去动它）。
//
//   ★ §5b 已删除——旧 Node 沙箱残留（2026-08-26 首次发现记录，
//   2026-08-26 CC 确认后完成删除；本段落记录最后一次完整引用检查
//   与删除结果）：
//   TestKit.js、runAllTests.js、900_Tests_Foundation.js、
//   912_Tests_ObligationEngine.js、919_Tests_ObligationIntegration.js、
//   999_Tests_PlatformVerification.js。彼此靠
//   require('../shim/GasShim')、require('./tests/900_Tests_Foundation')
//   这类路径互相引用，但 tests/、shim/ 两个子目录在目前 repository
//   里不存在——实际执行 node runAllTests.js 会立刻抛
//   "Cannot find module './tests/900_Tests_Foundation'"。
//   最终删除前查证（CC 明确要求的"最后一次 repository-wide reference
//   check"）：
//     - .claspignore 里"# Node js test run"分类下确实列出这 6 个
//       档名——但 .claspignore 只负责告诉 clasp push 时跳过哪些档案，
//       不代表档案本身能跑；这 6 个档名列在里面正好反过来印证它们
//       "本来就设计成 Node-only、从不推送到 GAS"，删除后 clasp 对
//       .claspignore 里列出但已不存在的档名不会报错，纯粹无操作，
//       已同步把这 6 行从 .claspignore 移除（见下方）。
//     - GasShim.js 唯一一处提到"900_Tests_Foundation.js"是行内注解
//       （说明 setNumberFormat 的用途），不是 require()，零功能依赖。
//     - 991_Tests_ObligationEngine.js 提到的是 990_TestKit.js（现役、
//       保留），grep "TestKit" 命中的是"990_TestKit"的子字串，不是
//       对已删除 TestKit.js 的真实依赖。
//     - 992/993/994_Tests_*.js 各自的注解都提到一个或多个已删除档名，
//       但全部是解释"这个 GAS-native 档案取代了什么"的历史说明句，
//       三份档案本身 require() 数量都是 0（纯 GAS-native，本来就不
//       透过 Node require 任何东西）。
//     - 990-996、918、922、900-903、910-913 等全部现役 Runtime/Test
//       档案，逐一 grep 后零真实功能引用。
//   结论：确认无任何现役档案功能性依赖这 6 个档名，删除安全，不影响
//   目前 GAS runtime、local precheck、真实 GAS 验证、clasp
//   deployment。CC 确认后已实际删除，不只是不交付。00_Project_State.js
//   都各自独立记录"property-os-tests/（旧 Node 沙箱）已于 2026-07-29
//   移除，不再是 Property OS 的一部分"——这批档案就是那次应该被移除、
//   却仍留在 repository 里的遗留物，跟 §5a 现役的
//   local_precheck_test_*.js 惯例是两个不同世代的产物，不要混淆。
//   00_Business_Rules.js BR-1 原本引用 919_Tests_ObligationIntegration.js
//   作为验证依据，已同步修正（见该档案本身）。删除后重新执行全部
//   语法检查与测试套件，结果见本次 housekeeping completion report。
//
// ★★ 2026-09-14 窗口（BL-13 Addendum 3/BL-17 Closure/BL-18 登记/M4
// Architecture Gate/M4 实作，BL-19）——本节此前一直没有更新到这个窗口，
// 2026-09-16 全窗口 checkpoint 稽核时发现这个落差，在此一次补齐：
//
//   .claspignore —— 重新补上 local_precheck_test_*.js wildcard（本次
//     上传的 zip 快照里缺失，governance 记录与实际档案不一致，详见
//     BL-13 Addendum 2）。现涵盖现役 8 个档案（非当初 7 个，
//     948_search 是第 8 个）。
//   911_DocumentEngine.js —— 逐字未动。dlp_attachDefectEvidence 的
//     clientRequestId 去重机制本次首次真机验证（2026-09-14，见 BL-13
//     Addendum 3、MANUAL_VERIFICATION_CHECKLIST.md）。
//   948_MobileConsole.html —— 本窗口新增 M4（Rectification Event
//     提交，BL-19）：一个新区块（7 个 EventType chip + 可选 Notes +
//     Submit），`openDefectDetail_` 新增对称状态重置，init 新增一行
//     呼叫，新增 setupRectificationEvent_/submitRectificationEvent_
//     两个函式，逐字比照既有 M2/M3 的 chip-then-submit 结构。918/947
//     逐字未动——完全复用既有 logRectificationEvent/
//     dlp_addRectificationEvent。真机验证：CC 已确认 Sheet 行数模式
//     （新记录/重复不增加/新记录）与手机 UI 操作正常，但 M1-M3
//     回归这一项本次 checkpoint 时仍未确认，见 CHECKPOINT_2026-09-16
//     的未解决事项。
//   local_precheck_test_948_rectification.js —— 新建（27 项）。测
//     全部 7 个 EventType 逐一真的透过 dlp_addRectificationEvent
//     提交成功（既有 947 测试只测过 1 个）、Notes 端到端保真、对
//     948 原始码的静态核对（clientRequestId 生成/传递、状态重置、
//     M2/M3 呼叫形状回归防线）。跑法：
//     node local_precheck_test_948_rectification.js。
//   新增的分析/报告档案（均为一次性交付文件，非治理档案本体，内容
//     摘要已同步进对应的 00_*.js/UI Contract）：
//     REPORT_2026-09-14_Step0-ClaspignoreFix_Step1-EvidenceVerificationPlan.md、
//     REPORT_2026-09-14_Step2-BL17-SearchSort-VerificationPlan.md、
//     GATE_2026-09-14_M4-RectificationEvent-ArchitectureReview.md（分析
//     结论：ADR-P15 早已分析并搁置 Repair Cycle 问题，M4 只需要
//     Option A，不需要新 ADR）、
//     IMPLEMENTATION_2026-09-14_M4-RectificationEvent.md。
//   DlpMobileConsole_UIContract.md —— §12 状态表：Search/Sort 行改为
//     VERIFIED；新增 Rectification Event 一行，状态
//     `IMPLEMENTED — LOCAL VERIFIED — GAS VERIFICATION PENDING`（这行
//     文字目前落后于最新对话进度——CC 已经给了部分真机证据，但因为
//     M1-M3 回归那一项还没确认，故意还没重新改这行，等确认后一次
//     写完整，不要看到这行文字就以为完全没有真机证据）。
//   MANUAL_VERIFICATION_CHECKLIST.md —— 新增 911_DocumentEngine
//     clientRequestId 段落（2026-09-14）、948_MobileConsole
//     Search/Sort 段落（2026-09-14）、以及对 2026-08-16 那笔 918
//     cache-hit 旧缺口的 reconciliation（追到 BL-13 原始 2026-09-08
//     证据，确认「已经做过，只是没打勾」，明确排除 Evidence 在外）。
//     M4/Rectification Event 尚未在这份档案里立项——比照 BL-17 的
//     既有惯例（这份档案只记录「真机证据已经存在」之后的结果，不
//     提前写全 PENDING 的段落），等 M4 的真机验证完全确认后才补。
//   00_Product_Backlog.js —— BL-18（945 补 clientRequestId，比照
//     948 已有的 generateClientRequestId_() 模式）：REGISTERED — NOT
//     IMPLEMENTED，本窗口未实施。BL-19（M4 Option A 实作）：见上方
//     948_MobileConsole.html 说明，状态文字同样落后于对话进度，理由
//     同上。
//
// ★★★ 2026-09-18 追记（D 项确认，闭环上述三处"落后于对话进度"的
// 备注）：CC 已逐项回报 M1 详情展开、M2 Owner Verification 提交、
// M3 Developer Status 提交、卡片/Overview 联动、Timeline 增量，全部
// 正常——D 项确认完成，CC 自己定义的 A-D 真机验证程序全部到齐。
// 00_Product_Backlog.js（BL-19）、DlpMobileConsole_UIContract.md
// （§12）、MANUAL_VERIFICATION_CHECKLIST.md 均已同步改为
// REAL-DEVICE VERIFIED（证据等级：CC 第一手具体叙述，逐项区分
// M1/M2/M3/联动/Timeline，非逐行原始 log；D 未给出精确 Timeline
// 行数，与 A/B/C 的"各只 +1 行"量化说法不同层级）。上方三处备注
// 均不再落后于对话进度。
//
// ═══════════════════════════════════════════════════════════════════════
// END OF 00_File_Map.js
// ═══════════════════════════════════════════════════════════════════════
