/**
 * ═══════════════════════════════════════════════════════════════════════
 * PROPERTY OS — 00_Product_Backlog.js
 * Product Backlog（未来功能，非现在实现）
 * ═══════════════════════════════════════════════════════════════════════
 *
 * 原则：这里记的是"未来要做什么、大概怎么做"的设计草图，不是
 * Vertical Slice——足够详细到未来真的要做时不用从零重新想一遍，但
 * 不到需要 Review Approval 的正式程度。真正要实现时，仍然要走
 * 完整流程（视复杂度决定要不要完整 Vertical Slice，比照 ADR-P14
 * 之后的 MVP 精神，不是每个功能都要 12 节文件）。
 *
 * 加入这里的项目，不影响、不阻塞当前 Operator Console MVP 的开发
 * 进度（CC 明确指示）。
 *
 * 本文件不包含任何可执行逻辑，仅为治理文档。
 * ═══════════════════════════════════════════════════════════════════════
 */


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Phase 11 — Real DLP/Defect Data Onboarding Gap 收集说明
// （2026-08-22 新增，见 00_Project_State.js CHANGELOG 同日条目）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// CC 明确指示：Phase 11 真实资料 onboarding 过程中，如果发现——
//   - 某个字段不够
//   - 某个 workflow 不符合实际
//   - 某个 Defect 类型无法表达
//   - Evidence 关联方式不够好
//   - Repair Cycle 问题真正出现（Failed Verification → Developer
//     修复 → 再次 ClaimedCompleted）
// ——先记录为 Feedback/Gap，不要立即修改 Runtime。除非是真正的 data
// integrity/safety bug，否则先完成整个真实案件的资料 onboarding，
// 再一次集中做 Gap Review，比照 BL-1（Leasehold Lease Expiry）当初
// "Operator Console 实战使用后的回馈"的模式——先真正用过一轮，再决定
// 要不要改、怎么改，而不是每发现一个不顺手的地方就改一次 Schema。
//
// 这样做的理由（CC 原话）：「更好的方式是先把真实案件完整录进去，
// 把所有『不顺手』的地方收集起来。等你这个 Case 真正跑过一轮，再
// 一次性做 Gap Review。这样你最后得到的不是『看起来很完整的
// Defect OS』，而是一个真的经历过你这套 EST8 DLP 流程的 Defect OS。」
//
// Phase 11 期间发现的每一项 Gap，之后会以 BL-N 的格式加进本文件（比照
// BL-1/BL-2/BL-3 的既有写法：需求 + 设计草图 + 依赖），不是现在预先
// 猜测会有哪些 Gap 就写占位内容——目前是空的，正如实反映"onboarding
// 还没开始，还没有真实 Gap 可记"这个事实。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-1 — Leasehold Lease Expiry（提出于 2026-07-29，Operator Console
// 实战使用后的回馈）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 需求：Leasehold 类型的 Property，需要记录：
//   - Lease Expiry Year（租约到期年份）
//   - Remaining Lease Years（剩余年限）
//   两者可互相推算，UI 只需输入其中一个。
//
// 设计草图（比照本项目已有的 Derived State 原则——Overdue、Cashflow
// 加总都是查询时算，不预先存）：
//   - Truth 只存 LeaseExpiryYear（number，一个不会因时间流逝而过期
//     的固定事实）。
//   - RemainingLeaseYears 永远是查询/显示时用 (LeaseExpiryYear -
//     当前年份) 现算，不落库存成第二份可能跟 LeaseExpiryYear 兜不
//     起来的数字——如果两个都存，明年这个数字就该变但没人会去改它，
//     变成一个每年都要手动更新的欄位，也违反 ADR-P02（Property OS
//     不建 Trigger，没有排程机制可以自动更新它）。
//   - UI 层面：两个输入框都给，使用者填哪个都行，另一个即时算出来
//     显示（纯前端 JS 算，不需要呼叫後端）；实际送出時只送
//     LeaseExpiryYear 给 Command。
//   - Schema 影响：910_PropertyAssetEngine 的 Property 实体新增
//     LeaseExpiryYear 栏位（number，仅 FreeholdLeasehold='Leasehold'
//     时有意义，Freehold 留空）。Additive-only，不影响既有资料。
//
// 依赖：无（纯粹是 910 自己的 Schema 扩充）


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-2 — Property Insurance（提出于 2026-07-29）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 需求：管理房产保险，至少记录 Insurance Company、Policy Number、
// Coverage Type、Coverage Amount、Premium、Renewal Date、Expiry
// Date。未来要能跟 Obligation Engine 整合，自动提醒续保。
//
// 设计草图：
//   - CC 提到"跟 Obligation Engine 整合、自动提醒续保"这句话本身
//     就点出了正确的架构方向：保险续保在本质上就是一笔"每年到期、
//     需要提醒、需要缴费"的 Obligation——OBLIGATION_CATEGORIES 里
//     已经有 'Insurance' 这个类别（900_PropertyConfig.js），Reminder
//     Offset、Overdue 判定、缴费记录这些 912/913 现成的机制，保险
//     续保完全用得上，不需要另外重造一套提醒/排程逻辑。
//   - 因此建议不是把 Insurance 做成完全独立的一套，而是：
//     (a) 一笔 Insurance Policy 对应一个 ObligationRule
//         (Category='Insurance', DueAnchor=Renewal Date)——续保提醒、
//         逾期判定、缴费记录，直接沿用 912/913，不重写。
//     (b) 新增一个独立的 PropertyInsurancePolicy 实体（新 Sheet），
//         只放 Obligation 既有 Schema 装不下的保险专属描述性资料：
//         InsuranceCompany、PolicyNumber、CoverageType、
//         CoverageAmount、ObligationID（FK，指向对应的
//         ObligationRule）。Premium/RenewalDate 已经就是
//         ObligationRule 的 Amount/DueAnchor，不重复存第二份。
//         ExpiryDate 单独存在这个新实体（跟 RenewalDate 通常不同一
//         天，续保跟保单到期是两个独立日期）。
//   - 这个设计沿用了 ADR-P01 的既有原则（Obligation Engine 是唯一
//     排程真相来源），没有为了 Insurance 这一个功能就开一个新的
//     排程/提醒机制——降低未来维护负担。
//
// 依赖：912_ObligationEngine（复用其 Category/Reminder/Overdue 机制）


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-3 — Management Information（提出于 2026-07-29）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 需求：每个 Property 可记录 Management Company；电话号码支援多个，
// 每个可标记类型（OFFICE/MOBILE/WHATSAPP/EMERGENCY/OTHER）；未来
// 可扩充 Email/Office Address/Operating Hours/备注。
//
// 设计草图：
//   - "多个电话号码，每个有类型"这件事，Google Sheets 没有 array/
//     nested 栏位类型可用——比照本项目处理 Address 的方式（拆成
//     AddressLine1/2/City/State/... 六个平面栏位，而不是塞一个
//     JSON 字串进单一格子），电话号码也应该拆成独立的子表，一行
//     一个号码，而不是塞进一个 JSON blob——一致性考量：整个项目
//     目前没有任何地方把结构化资料塞进单一栏位当 JSON 存，這裡也
//     不该开先例，不然以后 Query/Migration 都要多处理一种资料形态。
//   - 具体：新增 PropertyManagementContact 实体（PropertyID FK，
//     ManagementCompany 名称，主要联络人等未来可能加的欄位）+
//     PropertyManagementPhone 子实体（ManagementContactID FK 或直接
//     PropertyID FK，PhoneNumber，PhoneType enum: OFFICE/MOBILE/
//     WHATSAPP/EMERGENCY/OTHER）——一对多，几个号码就几行。
//   - Email/Office Address/Operating Hours/备注：等真的要做时再加
//     栏位，Additive-only 不影响既有资料，不预先把 Schema 撑大（
//     Speculative Design 原则——CC 自己也说"后续也可扩充"，用词上
//     已经是"以后要就加"，不是"现在就要有"）。
//
// 依赖：910_PropertyAssetEngine（新增两个子实体，与 Property 关联）


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// Backlog 项目通用注记
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 三项都是 Additive-only 的 Schema 扩充或新实体，不改动现有
// Property/Obligation 的既有栏位或行为，实现时不需要 Migration 之外
// 的相容性处理。真正排入开发时，按 ADR-P14 的精神决定要用多重的
// 流程去做——如果只是加欄位（BL-1），可能不需要完整 Vertical
// Slice；如果是新实体+新 Command（BL-2/BL-3），仍建议至少走一次
// 精简版设计再动手，避免像 Operator Console 这样，实战后才发现
// 设计缺口（例如这次跨 execution 一致性的 bug）。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-4 — 00_File_Map.js 完整 Manifest 重新核对（提出于 2026-08-26，
// Phase 11 Schema Migration 治理更新收尾时顺带发现）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 背景：Phase 11 DefectItem Schema Migration 期间（ADR-P18、
// 00_Review_History.js REVIEW-004），00_File_Map.js 只补上了本次新增
// 的两个档案条目（两个 ONETIME_Phase11_*.js）。CHECKPOINT_2026-08-26_
// Phase11-SchemaMigration.md 已明确记录：manifest 里 947/948 那段既有
// 落差在本次 Migration 之前就存在，未被本次覆盖或核对。
//
// 任务（跟 BL-1/2/3 性质不同，不是"需求+设计草图"式的功能，是文件
// 核对）：找时间对整份 00_File_Map.js 逐一核对是否与真实档案状态一致，
// 特别是 947/948 那段。不涉及 Schema 或 Runtime 变更，纯粹是治理
// 文件本身的准确性 housekeeping。
//
// 依赖：无。CC 明确指示（2026-08-26）不要在 Phase 11 Pre-Import Gate
// 这次的治理更新里顺手处理，避免打开一个"全 Repository manifest
// audit"的大范围任务——与当前主线（Schema Migration → 真实 Defect
// 数据输入 → Dry Run → Real Import → 实战 Feedback）无关，等这条主线
// 告一段落后再集中处理。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-5 — 三项 2026-08-26 BL-4 Housekeeping 期间发现、判定需要 CC
// 本人决定/操作、不该由 housekeeping 自行处理的事项
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// （1）ADR-P17 缺档：901_PropertySchema.js 注解、00_File_Map.js 的
// 2026-08-17 部署清单、ADR-P18/P19 的 Related ADRs，多处一致地把
// "ADR-P17"当成已存在、已批准的正式决定引用（内容：Property 新增
// DevelopmentName/UnitLabel 用 Additive 追加在 columns 最后，而非
// Reorder）。但 00_ADR_Log.js 逐条核对后，找不到 ADR-P17 自己的正式
// STATUS/CONTEXT/DECISION 条目——只有其他 ADR 提到它。这不是排版或
// 编号问题，而是要不要还原一段 Claude 没有亲身参与的历史决策内容，
// 属于 CC 判断范围。若 CC 想补，Claude 可以根据现有多处一致的
// 描述草拟一份忠于这些描述的 ADR-P17 条目，供 CC 核对/修改，而不是
// 自己直接定案写入正式 Log。
//
// （2）一批已确认死亡、需要 CC 自己在真实 repository 里清掉的孤立
// 档案：TestKit.js、runAllTests.js、900_Tests_Foundation.js、
// 912_Tests_ObligationEngine.js、919_Tests_ObligationIntegration.js、
// 999_Tests_PlatformVerification.js。详细证据见 00_File_Map.js §5b。
// 这次交付给 CC 的档案集里已经不包含它们，但 Claude 没有工具能直接
// 从 CC 自己的 repository / 真实 GAS 项目里删除档案，需要 CC 自己
// 操作（大概率只是本地/GitHub 端还留着旧档案，真实 GAS 项目本身
// 应该没有，因为 .claspignore 排除 Node-only 测试档案不推送）。
//
// （3）00_Project_State.js 页首"Current Version: v1.4.0-dlp-defect-
// engine-phase1-8"字串明显落后于实际进度（ADR-P18/P19、真实 Import、
// 真实 Consolidation migration 都已完成，不只是 Phase 1-8）。下一个
// 版本号怎么定（例如是否要反映到 Phase 11、要不要用语意化版本号）
// 属于 CC 的命名判断，Claude 不擅自决定写一个新版本号进去。
//
// 依赖：无——三项都是纯讨论/决定层级的事，不涉及 Runtime/Schema 变更
// 本身。均不阻塞 CC 目前的真实 DLP workflow 使用。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-6 — 00_Review_History.js 缺 REVIEW-005（提出于 2026-08-30，Mobile
// Console 栏位显示强化收尾 Governance 记录期间发现）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 发现经过：这次要为 Mobile Console itemId/subCategory/remark 栏位显示
// 强化写一笔新的 REVIEW 记录，选编号前先 grep 00_Review_History.js 核实
// 目前实际记录到哪——结果发现 00_ADR_Log.js（ADR-P19 CONSEQUENCES 段）、
// 00_Project_State.js（2026-08-26 CHANGELOG 条目）、00_File_Map.js
// （947/948 Status 段落 Next Steps）三处，都把"00_Review_History.js
// REVIEW-005"当成已经存在、可查阅的正式条目在引用——但
// 00_Review_History.js 里实际逐条核对，只有 REVIEW-001～004，没有
// REVIEW-005。
//
// 从这三处引用的描述拼出来，REVIEW-005 应该要包含：(a) ADR-P19
// OriginalReference→ItemID consolidation 的完整逐档案 impact
// analysis/verification（918 addDefectItem、ONETIME_Phase11_
// DefectImporter.js 的 dedup 逻辑与 staging schema、922
// enrichDefectForDisplay_ 输出栏位，三者的变更验证）；(b) 一份 Next
// Steps，记录 CC 决定两个 ONETIME migration 工具（Importer +
// SchemaReorderMigration）暂时都保留，等真实 onboarding 全部完成、确认
// 不再需要 rollback/rerun 后再议。
//
// 这跟 BL-5（1）的 ADR-P17 缺档不是同一种落差——ADR-P19 自己在
// 00_ADR_Log.js 里的条目、连同 900/901 的 schema 变更，都确实存在于这份
// repository；单单 00_Review_History.js 该有的 REVIEW-005 本身没写进去
// （或者写了但没有被包含在交付给 CC 的档案集里、CC 那边也没收到——两种
// 可能 Claude都无法从这份 repository 本身分辨）。
//
// 没有当场补写的原因：跟 ADR-P17 缺档同一个原则——这份 REVIEW 记的是
// "impact analysis 与 verification"，本质是对当时那次真实 Consolidation
// 工作的忠实记录，而 Claude 不是那次对话/那次真实操作的亲历者，手上没有
// 当时逐档案比对、逐项验证的第一手依据，现在补写等于是事后编一份看起来
// 像是当场写的记录，不诚实。
//
// CC 若想补：Claude 可以根据现有 repository 里 ADR-P19 变更后的实际代码
// （918/922/Importer 三处的 OriginalReference→ItemID 改动都还能直接读到、
// 直接核对）加上这三处引用描述的范围，草拟一份忠于"现在能查证到什么"的
// REVIEW-005 重建版本，明确标注是事后重建、不是当场记录，供 CC
// 核对/决定是否採用，而不是自己直接定案写入正式 Log。
//
// 依赖：无——纯文件缺口，不影响 Runtime，不阻塞 CC 目前的真实 DLP
// workflow 使用，也不阻塞本次（2026-08-30）Mobile Console 栏位显示
// 强化的 Governance 记录本身——本次改用 REVIEW-006，刻意跳过
// 005，把这个编号留给上述缺档，避免两份内容完全不相关的记录共用同一个
// 编号。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-7 — Sidebar DLP Tab Phase 1（提出于 2026-08-31，两个 vertical
// slice 均已实作，CC 真机验证通过）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 状态：★ 2026-09-01（同日稍晚）更新——IMPLEMENTATION COMPLETE
// （本地层面）→ CC 真机验证通过（"真机验证了，已经没问题了"，CC 原话，
// 一般性确认，非逐项 checklist）。vertical slice 1（Case Overview /
// Defect List / Defect Detail / Update Developer Status / Record Owner
// Verification）与 vertical slice 2（Rectification Event / Evidence /
// Secondary Damage / Correspondence）均已实作、本地验证通过、且现在
// 已有 CC 的真机确认。注意：这不等同于本项目 REVIEW-002 那种正式、
// 逐项的 PRODUCTION-READY Gate（Contract §11 的 11 步验证）——那个
// Gate 没有跑过，这里记录的是 CC 的一般性确认，不是正式认证，两者
// 层级不同，见 00_Review_History.js REVIEW-009 Addendum。
//
// 之前的真机测试细节（slice 1 单独测过一轮，Overview 当时空白）：
// Defect List/Detail/两个写入动作全部正常，Case Overview 空白——已定位
// 根因（getCaseTimeline 排序对非字符串 OccurredAt 直接 throw）并修复，
// 同时对 dlp_getSidebarCaseDashboard 加了跟 dlp_getCaseOverview 同款的
// JSON.stringify 防御。这个修复连同 slice 2 全体，后续这轮真机测试已
// 一并确认无误。完整记录见 00_Review_History.js REVIEW-008（slice 1）+
// REVIEW-009（slice 2 + Overview 修复 + 真机确认 Addendum）。
//
// ★ 流程备注：CC 授权继续 slice 2 时，slice 1 其实还没试——这跟"先吸收
// slice 1 真实回馈再做 slice 2"这个当初讲好的节奏正好相反。Claude 当场
// 提醒过一次，判断 slice 2 大部分是新增/独立功能、被牵连改写的风险不高，
// 照 CC 指示继续做了。事后来看，正因为这样"没等 slice 1 回馈"，slice 2
// 的新增函式（enrichRectificationEventForDisplay_ 等）才主动补了
// slice 1 当时还没有的防御性日期处理——等于是把从 Overview 那次真机
// 回馈里学到的教训，提前套用到了还没测试过的新代码上，而不是真的完全没
// 从这次真机回馈里受益。
//
// 范围：DlpSidebarTab_UIContract.md（独立文件，随本次交付给 CC，Claude
// 没有工具能直接把它加进 CC 自己的 repository——需要 CC 自己动作，跟
// BL-5(2) 那 6 个孤立档案同一种"Claude 只能交付档案、不能代替 CC 操作
// repository"限制）定案的 Phase 1：Defect List/Detail 查看、Update
// Developer Status、Record Owner Verification、Add Rectification
// Event、Add Evidence、Add Secondary Damage、Case 层级 Correspondence
// 查看。完整规格与所有决定见该文件 + 00_Review_History.js REVIEW-007 +
// 00_ADR_Log.js ADR-P20（947 统一 DLP glue 的架构决定）。
//
// 已实作（vertical slice 1，2026-08-31，★ 真机部分确认：List/Detail/
// 两个写入动作正常，Overview 原本空白已修复待复测）：922 的
// enrichDefectForDisplay_ 补 subCategory/remark；947 新增 6 个 dlp_*
// Sidebar wrapper（沿用既有 getDlpCaseDashboard/
// listDefectItemsForDashboard，未新增 922 聚合函式）；945 新增 DLP tab
// + Overview/Defects 子导航 + Detail 双动作表单。
//
// 已实作（vertical slice 2，2026-08-31/09-01，尚未真机验证）：922 新增
// buildDefectDetailForSidebar_（Contract §18 的 Detail-page 聚合函式，
// single-pass，明确不跟 buildCaseOverviewForMobile_ 合并）+ 4 个 enrich
// 函式；947 新增 4 个 dlp_* wrapper（dlp_addRectificationEvent/
// dlp_attachDefectEvidence/dlp_addSecondaryDamage/
// dlp_listSidebarCorrespondence），dlp_getSidebarDefectDetail 升级为
// 呼叫新聚合函式；945 新增 Correspondence 第 3 个子导航、Detail 页面
// 三个新区块（各自一个既有记录列表 + 一个 details/summary 收合式
// Add 表单）。
//
// Phase 2（明确不在这次 BL-7 范围内，本身也还没设计）：Close
// Defect、Reopen Defect、Close Case——见 Contract §15。
//
// 依赖：无 Runtime 依赖——纯粹是"vertical slice 1 已完成、vertical
// slice 2 等 CC 下一次明确授权才 coding"这件事本身需要一个 backlog
// 条目追踪，否则新窗口没有单一入口知道这件事定案到哪、做到哪、还没做
// 什么。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-8 — listDefectItemsForCase 对不存在的 caseId 不 throw（发现于
// 2026-08-31，BL-7 vertical slice 1 实作过程中，记录不修）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 现象：918_DefectEngine.js 的 listDefectItemsForCase(caseId) 只对
// DefectItem 表做 CaseID 过滤，从不检查这个 caseId 对应的 PropertyCase
// 是否真的存在——不存在的 caseId 会静默回传空阵列 []，而不是像
// getDlpCaseDashboard(caseId) 那样在同样情况下 throw
// DLP_CASE_NOT_FOUND。922_DashboardAdapter.js 的
// listDefectItemsForDashboard 直接沿用这个行为（未额外检查），947 新增
// 的 dlp_listSidebarDefects 也一样（纯 thin wrapper，忠实反映
// listDefectItemsForDashboard 的真实行为，未在 wrapper 层额外加检查）。
// 用 ad-hoc smoke test 直接验证确认，非推测——见
// 00_Review_History.js REVIEW-008 Findings。
//
// 影响：目前休眠、不影响实际运作——PROPERTY_CONFIG.ACTIVE_DLP_CASE_ID
// 是对的真实值。只有在这个值未来被错误改掉时才会体现：Case
// Overview（走 getDlpCaseDashboard）会正确报错，但 Defect List（走
// listDefectItemsForDashboard）会静默显示"没有 defect"，看起来像是
// Case 本身是空的，而非配置错误——两个本该反映同一件事的画面会给出不
// 一致的讯号。
//
// 设计草图（如果之后决定要修）：在 listDefectItemsForCase 或
// listDefectItemsForDashboard 里加一段 caseExists_(caseId) 检查（918
// 已有这个 helper，getDlpCaseDashboard 内部就是这样用的），不存在时
// throw 同一个 DLP_CASE_NOT_FOUND，让两个 Query 行为一致。这会是一次
// 918/922 的 Domain/Projection 层改动，不是单纯 947/945 UI 层可以处理
// 的事——照 Contract §14 的规矩，不在 Sidebar UI 工作的同一 session
// 里顺手改。
//
// 依赖：无——纯粹记录一个真实存在、目前休眠的行为不一致，等 CC 决定
// 要不要修、什么时候修。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-9 — local_precheck_test_phase11_defectitem_reorder_migration.js
// 有个失效已久的断言（发现于 2026-08-31，BL-7 实作过程中顺带跑全套
// regression 时发现，与 Sidebar DLP 工作本身无关，记录不处理）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 现象：这个测试文件对应 ONETIME_Phase11_DefectItemSchemaReorderMigration.js
// （较早的一次 schema 重排 migration），其中一条断言仍然预期
// OriginalReference 栏位存在，但 ADR-P19（2026-08-26 Schema
// Consolidation）已经把 OriginalReference 併入 ItemID、从 901 schema
// 里拿掉——这个测试没有跟着 ADR-P19 更新，变成一个针对已经不存在栏位的
// 过时断言。
//
// 已核实非本次改动造成：用一份干净的、未经任何本次改动的原始上传单独
// 解压跑同一个测试文件，产生完全相同的失败（同一行、同一段错误讯息）——
// 这次 Sidebar DLP Tab vertical slice 1 的改动完全没有碰过这个测试
// 文件或它对应的 migration 脚本。
//
// 影响：不影响 Phase 1 Sidebar DLP 工作，也不影响任何已 Production-
// Ready 的子系统——ONETIME_Phase11_DefectItemSchemaReorderMigration.js
// 本身早于 ADR-P19 的合併，跟 ONETIME_Phase11_
// DefectItemSchemaConsolidationMigration.js（后者的测试全数通过，
// 38/38）已经是被取代的关系。00_Product_Backlog.js 顶部"Phase 11 Gap
// 收集说明"段落已记录 CC 的既有决定：三个 ONETIME_Phase11_*.js
// 脚本保留不归档，等真实资料 onboarding 完全跑完、不再有 rollback/
// rerun 风险后再重新检视——这个失效断言可以留到那次检视一并处理，不需
// 要现在单独修。
//
// 依赖：无——纯粹记录一个跟本次 Sidebar 工作无关、但顺带核实过的既有
// 缺口，避免之后有人重新发现同一件事却以为是新问题。

// BL-10 — local_precheck_test_911.js 整个测试文件跑不起来（发现于
// 2026-09-01，CC 要求的全窗口重新核对过程中顺带跑全套 local_precheck_
// test_*.js 才发现，此前整个会话都没跑过这个文件，与 Sidebar DLP
// 工作本身无关，记录不处理，但跟新增的 Evidence 上传功能直接相关）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 状态：★ 2026-09-04 更新——VERIFIED（真机手动验证，非本地自动化
// 测试）。CC 逐项跑过自订 checklist（A-I）：Sidebar 挑一个真实
// defect，刻意选用非预设的 EvidenceType/Phase（不是只测 default
// 值），上传一张真实照片，收到"Evidence uploaded"、Evidence 列表
// 立即刷出新纪录；到真实 Google Drive 的 Property OS Evidence /
// CASE-msxyfkpi-zu4j 资料夹核实档案确实存在、内容对得上；到
// Evidence sheet 核对新增那一行，DriveFileID 与 Drive 里的档案 ID
// 一致，其余栏位（CaseID/DefectID/EvidenceType/Phase 等）皆正确。
//
// 这条验证是逐项、非"CC 一般性确认"——跟 BL-7 状态更新里特别标注
// 的"一般性确认，非逐项 checklist"不是同一个层级，这次明确逐项
// 过了 checklist，包含刻意测非预设值这个原本担心会被漏测的边界
// 情况。
//
// 没有改变、仍然成立的部分：local_precheck_test_911.js 仍然无法
// 在本地跑（GasShim 依旧没有 mock PropertiesService/DriveApp），
// 这次验证走的是真机手动测试，不是补上自动化本地覆盖率——往后这
// 条路径如果被改动，仍然没有本地测试能抓回归，只能靠再一次真机
// 手动测试。
//
// 与 BL-11 的关系：BL-11（attachEvidence 里 Drive 写入成功、Sheet
// 写入失败这段没有 try/catch 保护）记的是失败路径，这次是成功
// 案例，两者互不影响——BL-11 原样维持 deferred，不因为这次验证
// 成功而关闭或改变判断。
//
// 现象：这个测试文件测的是 911_DocumentEngine.js 的 attachEvidence 真实
// 上传路径（base64Data → saveEvidenceFile_ → 真实 DriveApp/
// PropertiesService 呼叫）。跑起来直接整个 crash：
// ReferenceError: PropertiesService is not defined，出在
// getEvidenceRootFolder_ 里第一行呼叫 PropertiesService.
// getScriptProperties() 的地方——不是断言失败，是整个测试进程连跑都跑
// 不完，卡在 attachEvidence 真实上传这一条路径上。
//
// 已核实非本次改动造成：用一份干净的、未经任何本次改动的原始上传单独
// 解压跑同一个测试文件，产生完全相同的 crash（同一行、同一段错误堆疊）
// ——本次 Sidebar DLP Tab 两个 vertical slice 的改动完全没有碰过 911_
// DocumentEngine.js 或这个测试文件本身。
//
// 影响：GasShim 本地测试环境本来就没有 mock PropertiesService/DriveApp
// 这类原生 GAS 服务，这条既有的本地测试落差本来就存在——不是这次才
// 出现。但这次新增的 dlp_attachDefectEvidence（vertical slice 2）
// 依赖的正是这同一条 attachEvidence 真实上传路径，意味着这个新功能的
// 真实 Drive 写入这一段，在本地完全没有、也没办法有自动化测试覆盖——
// Claude 自己对 dlp_attachDefectEvidence 的验证走的是 driveFileId 已
// 存在这条捷径（证明 wrapper 逻辑本身没问题），并不等于验证过真实
// base64 上传这条路径。CC"真机验证了，已经没问题了"是否具体包含实际
// 上传过一个真实档案，本身也没有单独确认——见本次 checkpoint 文件
// 第 3 节。
//
// 依赖：无——纯粹记录一个跟本次 Sidebar 工作无关、但顺带核实过的既有
// 测试环境缺口，避免之后有人重新发现同一件事却以为是新问题，同时提醒
// Evidence 上传这一段的真实验证覆盖率比表面上看起来的低。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-11 — attachEvidence() 里 Drive 写入与 Sheet 写入之间没有
// failure window 保护（发现于 2026-09-04，CC 要求为 BL-10 真机验证
// 先做 code-level readiness check、逐行核对 911_DocumentEngine.js
// 才发现，与本次 Sidebar DLP 工作或 Slice 1/2 改动本身无关，但直接
// 影响 BL-10 要验证的这条 Evidence 真实上传路径）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 现象：attachEvidence(input) 在没有现成 driveFileId 时会先呼叫
// saveEvidenceFile_(...) 把档案真的写进 Drive、拿到新的 driveFileId，
// 紧接着呼叫 generateEvidenceId_() 产生 evidenceId、组出 evidence
// 物件，再呼叫 evidenceSheet_().appendRow(objectToRowArray_(evidence,
// ...)) 写进 Evidence 表——saveEvidenceFile_ 成功之后、appendRow 之前
// 这一段完全没有 try/catch。往下一段，Timeline entry 与 Event
// publish 失败时是有 try/catch 包住，而且明确呼叫
// logDocumentEnginePartialFailure_('attachEvidence', 'Evidence ' +
// evidenceId + ' row was written (and a new Drive file saved, if one
// was uploaded); Timeline/Event publish failed.', e)——代表写这段
// 代码的人已经想过、也处理了"sheet 行已经写、后续步骤失败"这个情境，
// 但没有对称地处理更早、"Drive 档案已经写、sheet 行还没写"这个情境。
// 如果 generateEvidenceId_()、objectToRowArray_() 或 appendRow()
// 本身在这段抛出例外，呼叫方会拿到一个例外，但 Drive 里已经真实
// 存在一个档案，Evidence 表完全没有对应行、连 EvidenceID 都不存在
// ——错误讯息完全不会提示"其实档案已经建了"这件事。
//
// 关联既有记录：911_DocumentEngine.js 整个 Sidebar DLP Tab 工作期间
// （Slice 1 + Slice 2）零改动，本次 checkpoint 的 Repository diff
// 已确认——不是本次改动引入的问题，是 attachEvidence() 一直以来的
// 既有行为。Mobile Console 既有的 dlp_attachEvidence（早于本次
// Sidebar DLP 工作、独立于 Slice 1/2）呼叫的正是同一个
// attachEvidence()，这个 gap 不是 Sidebar 独有。（跟 BL-9/BL-10
// 用干净原始上传另外跑测试比对的方法不同——这次是直接读本次上传
// zip 里的 911 原始码、对照 checkpoint 既有的 diff 结论得出，方法
// 不同，结论方向一致，如实记录方法差异。）
//
// 影响：机率低——appendRow() 本身很少失败，generateEvidenceId_()、
// objectToRowArray_() 都是纯函式，正常情况下不会抛例外，目前没有
// 任何已知案例真的撞上这个窗口。真撞上的后果：Drive 里留下一个
// 孤儿档案，不会自动清除，也没有任何 Evidence/Case/Defect 记录
// 指向它；使用者如果照错误讯息重试，可能造成同一份档案被传两次
// （一次孤儿+一次成功记录），需要人工去 Drive 核对才会发现。不
// 影响 Case/Defect 主数据完整性——只影响 Evidence 附件这一层，
// 而且只在 appendRow 这一步真的失败时才会触发。
//
// 设计草图（如果之后决定要修）：把 generateEvidenceId_() 到
// appendRow() 这段包进 try/catch，失败时比照下面 Timeline/Event
// 那段的写法呼叫 logDocumentEnginePartialFailure_，讯息里明确带出
// 已经写入 Drive 的 driveFileId，方便之后人工核对、清理孤儿档案，
// 而不是让呼叫方从错误讯息里完全看不出"其实档案已经建了"。这是
// 911_DocumentEngine.js 单一函式内部的改动，不涉及 Schema/Domain 层。
//
// 依赖：无——纯粹记录一个真实存在、目前从未被撞过的既有缺口，等
// CC 决定要不要修、什么时候修。


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// BL-12 — Secondary Damage Contract Alignment（发现于 2026-09-04 的
// DLP Phase 1 Remaining Slice readiness检查，实作于同日）
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//
// 现象：logSecondaryDamage（918）接受 8 个栏位，945 的 Add 表单只
// 收集其中 5 个——administrativeSubmissionRequired/dlpPrejudiceStatus/
// contractualBasis 这三个栏位既有的 Contract §9 把它们列为正常输入
// 的一部分，但 grep 过 Contract 全文跟 00_Review_History.js，都没有
// 找到"故意不做"的记录，不像 rectificationEventId 挑选器（Contract
// §9 明文说不需要）或 status 更新（Contract §9 明文说 not requested）
// 那样有明确交代。
//
// ⚠ 一个更正：上一轮 readiness report 曾经说 947_DlpConsoleServer.js
// 的 dlp_addSecondaryDamage 也没有转发这三个栏位——这是 Claude 那一
// 轮的读取/转写错误，不是 repository 真的这样。实作这轮重新对照原始
// zip 逐字核对过：947 其实一直都有转发全部四个栏位（含
// separateSubmissionId），只是 945 的表单从来没有收集、也没有送出
// 这些栏位，所以 947 收到的永远是 undefined，最后存成 false/空字串
// ——问题从头到尾只在 945 这一层，947 完全不用改。已经把这个更正
// 交代清楚给 CC，这里如实记录，不掩盖。
//
// 已实作：945_OperatorConsole.html 的 Add Secondary Damage 表单新增
// 三个栏位（checkbox + 两个 text input，沿用既有 ob_autoGenerate
// 的 checkbox 样式），submitDlpAddSecondaryDamage 的 input 物件加上
// 对应三行；读取视图补上 Contractual Basis 这一栏（
// administrativeSubmissionRequired/dlpPrejudiceStatus 原本就有显示）。
// 947/918/922/901 全部未改动——四层都已经支援这三个栏位，只差 945
// 这一层没接上。
//
// 本地验证：抽出 945 的 <script> 区块跑 node --check，语法通过；
// diff 对照 Phase A 版本确认改动范围精确落在 SecondaryDamage 这一段；
// local_precheck_test_918.js 的 Phase 7 区块新增三个断言，直接呼叫
// logSecondaryDamage 传入这三个栏位的非默认值，跑过——147 项全部
// 通过（原本 144 项 + 新增 3 项），过程中新增的测试一度让既有的
// "listSecondaryDamageForCase returns both"断言失败（因为新记录用了
// 共用的 caseId，把该 Case 底下的笔数从 2 笔变 3 笔）——改成用同一
// 测试区块里既有的 otherCase 变量后修好，147 项全部通过，如实记录
// 这个过程，不是一次就对。947 层本身没有本地测试可跑（跟其他所有
// dlp_* wrapper一样，没有 local_precheck_test_947.js），这轮也没
// 新增——947 完全没改动，没有新代码需要测。
//
// 真机验证：★ 2026-09-06 更新——VERIFIED。CC 确认 Secondary Damage
// 三个缺失栏位对齐（涉及 945）在真实专案里运行正确。
//
// 依赖：无——947/918/922/901 全部不用改，纯粹是 945 这一层补齐。

// BL-13 — DLP Mobile Field Console Retry-Safety Foundation（提出于
// 2026-09-06 的 Decision & Idempotency Gate 分析，本次实作）
//
// 背景：Owner 核准 DLP Mobile Field Console Option C（原地扩充 948），
// 在真正曝光 Mobile UI 之前，先要求针对 recordDeveloperStatus/
// recordOwnerVerification 做完整 idempotency 分析（因为 Mobile 讯号不
// 稳，重复点击/网路 timeout 后重试是真实场景）。
//
// 分析发现（逐行核对 918/947/911/903 源码，非推测）：
// - recordDeveloperStatus/recordOwnerVerification 都是 Set 语意（覆写
//   DefectItem 同一行），重复调用不会让权威 Status 值本身出错，但
//   appendCaseTimelineEntry_ 完全没有天然去重，重复调用会真的多写一笔
//   一样的 Timeline 记录。
// - publishPropertyEvent_ 目前只是 ADR-P07 讲好的 placeholder（只做
//   Logger.log，没接真实 EventBus），重复触发目前零实际后果——但这是
//   "还没接线"，不是"设计上保证安全"，EventBus 真的接上后会变成真的
//   风险。
// - logRectificationEvent/attachEvidence/logSecondaryDamage（还有
//   addDefectItem/logDailyProgressCheck）这几个 918/911 Domain Command
//   本来就支援 clientRequestId，但 947 的 dlp_addRectificationEvent/
//   dlp_attachDefectEvidence 这两个 wrapper 一直没有把这个欄位转传
//   进去——Domain 层有支援，Bridge 层没接上，是两回事。
//
// 决定（Recommended Option B，Owner 核准）：两个函数都加
// clientRequestId，不是只加一个——两者风险形状完全对称，没有理由只保护
// 一个。判断这是 Domain-level integrity capability，不是 Mobile 专属
// workaround，所以放在 918，不是在 947/948 做局部修补（Sidebar 虽然
// 连线比较稳定，但同样的保护逻辑上也适用，没道理只让 Mobile 受益）。
//
// 实作（本次范围，只做这一个受控 safety slice，不碰 Mobile UI）：
// - 918_DefectEngine.js：recordDeveloperStatus/recordOwnerVerification
//   两者最前面加 clientRequestId cache-check、成功后加 cache-write，
//   一字不改地比照 logDailyProgressCheck 既有写法，复用同一套
//   getCachedDefectEngineCommandResult_/cacheDefectEngineCommandResult_
//   （CacheService，3600 秒 TTL，propertyos_idem_defect_ 共用命名空间）。
//   两份 docstring 同步补上 clientRequestId 参数说明。
// - 947_DlpConsoleServer.js：dlp_recordDeveloperStatus/
//   dlp_recordOwnerVerification 补上转传 clientRequestId；
//   dlp_addRectificationEvent/dlp_attachDefectEvidence 也补上（原本
//   注解写"刻意不传"，本次连同注解一并更新为如实反映现况）。
//   dlp_addSecondaryDamage 依 Owner 指示不动，检查过既有行为无恙。
// - 新增 local_precheck_test_947.js——947 从建立以来第一个本地测试档案，
//   专测 Bridge 层转传行为本身（不是重测 918 已经测过的 idempotency
//   机制），Owner Verification/Developer Status/Rectification Event 三者
//   走真实呼叫（都不碰 Drive），Evidence 用既有 driveFileId 捷径避开
//   local_precheck_test_911.js 那个已知、不相关的 PropertiesService gap。
// - local_precheck_test_918.js 新增 16 项断言（含一个刻意的跨 Command
//   cache-key 碰撞测试——证实这个快取命名空间本来就是全部 Defect Engine
//   Command 共用、不分 Command 各自独立，这是既有设计特性，addDefectItem
//   也是这样，非本次引入，也不是本次要解决的问题，如实记录）。
//
// 验证：本地测试全部真的跑过，不是只读代码——918 从 147 项增加到 163 项
// 全过，新增的 947 测试档案 13 项全过，922 既有 67 项不受影响，911 维持
// 跟修改前一模一样的既有 PropertiesService 崩溃（不相关、非本次造成）。
// 真机 / 真实 GAS 验证：★ 2026-09-08 更新——Developer Status/Owner
// Verification/Rectification Event 三项 VERIFIED。CC 在真实专案的 Apps
// Script Execution Log 里对一个真实 defect（DefectID 5124）实际跑过，
// 三项都拿到"命中快取，Timeline 严格增加 1 笔"的结果，另外独立到
// PropertyCaseTimeline 分页手动核对最后写入的时间戳，确认没有因为重试
// 产生双胞胎记录（不是只信脚本自己回报的成功讯息）。Evidence
// （dlp_attachDefectEvidence）这次的 log 里没看到——不确定是没测还是
// 只是没贴出来，待 CC 确认；在那之前 Evidence 这条路径维持
// IMPLEMENTED — UNVERIFIED，不要假设它也一并过了。
//
// 明确没做的（Owner 划定的范围之外）：Mobile Defect Detail UI、Owner
// Verification/Developer Status/Rectification Event/Evidence 的任何 UI、
// Secondary Damage、Correspondence、Close/Reopen/Close Case、EventBus
// 真正实作、BL-11 孤儿档案回收、Schema 改动。
//
// 治理：不需要新 ADR（延伸既有 pattern 到另外两个函数，没有引入新架构，
// 这个判断本身也是这次分析的一部分，不是事后才想到）。
// DlpMobileConsole_UIContract.md 的修订留到真正曝光给 Mobile UI 那一轮，
// 这次改动还没有任何 Mobile 使用者看得到。
//
// 依赖：无新增——完全建立在既有 918/911 的 CacheService 快取机制上，
// 901 schema 不用改（clientRequestId 是暂存 1 小时的 cache key，不是
// persisted 栏位）。
//
// Addendum（2026-09-06，套用真实专案前的部署安全清理，同一个 BL-13，
// 不另开新条目）：真实专案套用前的readiness稽核发现两个跟本项目本身
// 正确性无关、但会影响能否安全部署的问题，本次一并处理——
// (1) .claspignore 原本没有排除现役世代的 local_precheck_test_*.js
// （911/918/922/947/三个 phase11 migration 档案），这几个档案顶层有
// require('./GasShim.js')，是 Node 专属语法，如果整批 clasp push 会让
// 真实专案所有函式都跑不动；现在加了一行 wildcard
// （local_precheck_test_*.js）涵盖现役与未来的同名档案，用一个独立
// 撰写、跑完即删除的静态验证脚本确认过这个 pattern 精确涵盖全部 7 个
// 现役档案、完全不影响任何 runtime 档案或既有治理排除规则。
// (2) local_precheck_test_947.js 里两处比较 r1.defectId/r2.defectId
// 的断言本身没有鉴别力（947 的 dlp_wrap_ 把真正结果包在 .data 底下，
// 两边其实都是 undefined）——修正为 retry 故意送一个不同的
// developerStatus/ownerVerificationStatus，断言拿回来的必须是第一次
// 呼叫的值，这样真的能证明是命中快取而不是巧合算出相同结果。修正后
// 947 测试仍是 13/13 全过，但现在这两处断言有真正的鉴别力。
// 顺带一提（不属于本次范围，如实记录）：922 regression 跑的时候遇到
// 一次间歇性失败，之后连续跑 20 次都过，判断是既有、跟本次改动无关的
// test flakiness，未去调查根因或修复。另外核对 .claspignore 时也注意
// 到 990-996 那批档案不在排除清单里，但它们不用 require()，不属于
// 这次要处理的同一种风险，未进一步调查。
//
// Addendum 2（2026-09-14，新窗口从 2026-09-11 checkpoint 重新开始时发现）：
// 上面 Addendum 1 声称已经加上的 local_precheck_test_*.js wildcard，实际
// 并不存在于这次上传给新窗口的 repository 快照里的 .claspignore——
// governance 记录与实际档案内容不一致，新窗口没有仅凭 Addendum 1 的叙述
// 就假设已完成。已重新补上同一行 wildcard，用同样手法（独立撰写、跑完
// 即删除的静态验证脚本）重新确认：这次涵盖现役 8 个档案（比 Addendum 1
// 写的 7 个多一个 local_precheck_test_948_search.js——2026-09-09 才新建，
// Addendum 1 写的时候还不存在；用 wildcard 而非条列档名，本来就是为了
// 不必因为新增同名档案而回来改这一行，这次验证只是确认这个设计确实如
// 预期生效），且同样确认不误伤任何 runtime/domain 档案。未调查这个
// governance/reality 落差最初是怎么发生的（例如：修正是否只套用到真实
// GAS 专案本身、没有同步回被打包进这份 zip 的那个来源）——不在这次修正
// 范围内，如实记录待查。

// Addendum 3（2026-09-14，Step 1 closure）：CC 在真实 GAS 环境执行了 Addendum 2
// 之后规划的两段验证，针对 dlp_attachDefectEvidence 的 clientRequestId
// 去重机制（不是重新测 Evidence 上传本身——那部分 2026-08-17 已经验证过，
// 这次刻意分开看，详见 MANUAL_VERIFICATION_CHECKLIST.md 新增的
// 911_DocumentEngine clientRequestId 段落）。ALL TESTS PASSED，逐项核对
// Execution Log 而非只看总结行：相同 clientRequestId 重打，两次呼叫回传
// 逐位相同的结果物件（同一个 EvidenceID DOC-mu1hkgxc-ud7p、同一个
// UploadedAt/CreatedAt 时间戳、同一段 Description 文字），Evidence 表与
// Timeline 表两次呼叫合计各只多 1 笔——是真正命中快取重放，不是巧合的
// ID 重复。换一个 clientRequestId，产生真正独立的新 EvidenceID
// DOC-mu1hkitv-l61q、新时间戳，各表再各多 1 笔，证明快取 key 是
// clientRequestId 本身、不会误挡合法的第二次附件。唯一没有直接做到的：
// 第二次呼叫后没有回头重读、逐位比对原始那笔记录，只能从 appendRow 的
// 只增不改语义与精确的行数增量间接推断原记录没被动到，未直接眼见为凭
// ——已如实记录在 checklist 里，不算过（append-only 结构上不太可能被
// 动到），但不是同一等级的确认。
//
// 状态用词精确区分：clientRequestId 去重「机制」在真实 GAS 里已验证
// 正确（Production Verified，针对这个机制本身）；但**不等于**「945 的
// Evidence 上传现在对使用者来说是幂等的」——因为 945 目前的实际呼叫
// 完全不带 clientRequestId（见上方讨论），这道 backstop 在日常 Sidebar
// 操作下仍然摸不到。945 本次继续未修改。
//
// 因此 CC 要求「单独评估」的 Backlog item 在此提出评估，尚未正式加入
// 本档案、也未授权动 945：把 945 的 dlp_attachDefectEvidence 呼叫改成
// 跟 948 的 dlp_attachEvidence 一样，用既有的 generateClientRequestId_()
// 送出 clientRequestId，让两个 Evidence 相关的 947 wrapper 有一致的
// idempotency propagation contract。影响范围预估：只动 945_OperatorConsole.html
// 一处呼叫端，947/911 后端已经支援、不需要改；风险预估低（948 已经用
// 同一个 generateClientRequestId_() 生成方式在真实环境跑了一段时间）。
// 是否要把这个正式编成 BL-18 并排入 Backlog，等 CC 明确答复。

// BL-14 — Mobile Defect Detail MVP，M1 只读展开（提出并实作于 2026-09-08，
// Idempotency Gate 报告规划的 Slice M1-M5 第一个）
//
// 背景：BL-13 的 Developer Status/Owner Verification/Rectification Event
// 三项已在真实 GAS 环境验证（Evidence 待确认，维持 IMPLEMENTED —
// UNVERIFIED），Owner 核准从 M1 开始实作 Mobile Defect Detail——只读展开，
// 不含任何 mutation 控件（Owner Verification/Developer Status/
// Rectification Event/Evidence 的写入动作留给之后 M2-M5）。
//
// 实作：
// - 947_DlpConsoleServer.js：新增 dlp_getMobileDefectDetail(input)——薄
//   wrapper，直接重用既有 buildDefectDetailForSidebar_（922，零改动），
//   比照 dlp_getCaseOverview 的 JSON.stringify 防御模式。刻意不重用
//   dlp_getSidebarDefectDetail 本体、另开一个新函式，避免这次改动碰到
//   Desktop 已经在用、已经验证过的既有 wrapper。
// - 948_MobileConsole.html：新增第三个 view（view-defectDetail），沿用
//   既有 .view/.view.active 切换模式，不加路由库。Case Overview 的
//   Defect 卡片变成可点击，导向这个新 view；新增返回键回到 Overview（不
//   是回到 Daily Check）。Identity/Description/Priority-State/Dates 四组
//   栏位、加 Rectification Events/Evidence 两份只读列表——全部沿用既有
//   CSS class（summary-box/summary-line/field/badges/card/timeline-item/
//   empty/loading/back-row/back-btn），没有新增任何样式。Secondary
//   Damage 刻意不显示，即使 947 回传的 bundle 里就有——Contract §1/§9
//   本来就规定 Mobile 连只读都不给看 Secondary Damage，这次维持同一
//   限制，没有因为资料"反正都拿到了"就顺便显示出来。
// - local_precheck_test_947.js：新增 9 项断言测这个新函式（含刻意测试
//   不存在的 defectId、完全没给 defectId 两种情境，确认都是
//   {success:false} 而不是丢例外），13→22 全过。918（163/163）、922
//   （67/67）不受影响，911 维持既有 PropertiesService 崩溃不变。
//
// 已知边界（如实记录，不是缺陷）：M1 这类跑在浏览器里的 client-side
// 行为（卡片点击、view 切换、栏位实际渲染、返回导览）没有对应的本地
// 自动化测试可跑——948 从建立以来就没有 local_precheck_test_948.js，这
// 次也没有新建一个，因为要真的模拟浏览器 DOM 环境是比这次范围大很多的
// 基础设施投入。这些行为改用静态代码核对（确认新代码完全没有意外混入
// 任何 mutation RPC 呼叫、确认 948 全档案没有任何直接 Sheet 存取、确认
// 新 view 沿用的是 openOverview() 已经真机验证过的同一套 timeout/
// JSON.parse/错误处理模式）取代真机验证，不是真机验证的替代品，只是
// 在没有真机测试之前能做到的最高确定性。
//
// 真机 / Real-GAS 验证：★ 2026-09-08 更新——VERIFIED。CC 在真实专案对
// DefectID 5124 做了编辑器 Smoke Test（Execution log 确认回传类型是
// string、成功解析、Category/Events/Evidence 笔数正确、
// SecondaryDamage 确实存在于 payload 里）+ 真机点击：手机点卡片秒级
// 展开详情，无白屏或序列化问题，字段渲染完整无错位，Secondary Damage
// 未泄漏、没有多余可写控件，返回导航正常。之前 M1 报告里"担心
// Rectification Events/Evidence 巢状 payload 重演 dlp_getCaseOverview
// 序列化问题"的疑虑，这次真机确认没有发生。
//
// 依赖：无新增 Domain 行为——完全建立在既有 buildDefectDetailForSidebar_
// 上，901 schema 不用改。

// BL-15 — Mobile Defect Detail MVP，M2 Owner Verification 写入（提出并
// 实作于 2026-09-08，M1-M5 第二个）
//
// 背景：Owner 明确指示"code可以往前走，status不行"——M1 还没真机验证，
// 但 Owner 人不在电脑前，先允许 M2 开发+本地验证，不等 M1 真机结果。
// Owner Verification 的 918/947 两层在 BL-13 已经真机验证过，这次只是
// 把既有能力接上 UI。
//
// 实作：947/918 逐字未动——dlp_recordOwnerVerification/
// recordOwnerVerification 从 BL-13 起就已经支援 clientRequestId，这次
// 直接原样重用。全部改动在 948：Defect Detail 新增"Owner Verification"
// 区块，三个选项（Verified/Failed/Partial）+ 一个 Submit 按钮，沿用
// Daily Check 既有的"点 chip 选、按按钮才真的送出"两段式模式，而不是
// 点了就送。Submit 时才生成 clientRequestId（重试同一次尝试才重用，
// 新的一次有意义的操作会拿到新 ID），成功后重新呼叫 openDefectDetail_
// 整个重抓一次权威资料，而不是自己在 DOM 上局部拼贴。
//
// 过程中发现并修正一个真实、自己造成的 bug（不是既有缺陷）：Daily
// Check 既有的 chip 点击绑定用的是 unscoped
// document.querySelectorAll('.chip')，如果 Owner Verification 的选项也
// 用 .chip 这个 class，会被这段既有代码一併抓到，点 Owner Verification
// 的选项会连带把 Daily Check 的 dc_generalStatus 欄位写成字串
// "undefined"、还会清掉 Daily Check 原本选取的 chip。发现后新增一个
// 独立的 .ovchip class（视觉上跟 .chip 一模一样，只是 class 名称不同，
// 不会被那段既有的 unscoped selector 选到），而不是去改 Daily Check
// 那段已经真机验证过的既有代码。
//
// 测试：947（22/22）、918（163/163）、922（67/67）全部不受影响——
// Owner Verification 的 server 端逻辑本来就没有新代码，这次单纯是接
// 既有能力到新 UI，没有新的 server 端断言好加。948 的 client-side 行为
// （chip 点选、Submit 按钮 disable/enable、成功后重抓）跟 M1 一样没有
// 本地自动化测试基础设施，改用同一套静态核对：抽出 <script> 单独
// node -c 语法检查、grep 确认零直接 Sheet mutation、grep 确认没有
// 意外混入 M3/M4/M5 的任何 mutation 呼叫（dlp_recordDeveloperStatus/
// dlp_addRectificationEvent/dlp_attachDefectEvidence/
// dlp_addSecondaryDamage 一个都没有）、grep 确认
// dlp_recordOwnerVerification 确实只在这次新增的一个地方被呼叫。
//
// 真机 / Real-GAS 验证：★ 2026-09-08 更新——mutation 路径本身
// VERIFIED，同时发现并当场修正一个 UI bug（细节见下）。CC 真机测试
// Owner Verification，回报"功能和记录一切正常"——提交后 Timeline/
// OwnerVerificationStatus 确实按预期更新，clientRequestId 路径在真实
// 环境下也确认工作正常。
//
// 发现的 bug（真机测试才暴露，本地静态核对无法测到）：Submit Owner
// Verification 按钮在未选取任何选项时应该是 disabled，但 .btn-secondary
// 这个 class 从来没有对应的 :disabled 样式规则（.btn-primary 有，
// .btn-secondary 没有）——导致停用状态跟可点击状态视觉上一模一样，CC
// 一开始的描述是"看似可用，但是按钮按不到"，也就是先点了 Submit（那
// 时候还没选 chip，浏览器原生行为正确地挡下了点击，但完全没有视觉提示
// 告诉使用者为什么点不动）。修法：新增 .btn-secondary:disabled
// { opacity:.5 }，比照 .btn-primary 既有写法。检查过
// addEvidenceBtn/doneBtn 这两个也用 .btn-secondary 的既有按钮从来没有
// 被设成 disabled 过，这次新增的样式规则不会影响它们已经真机验证过的
// 外观。★ 2026-09-09 更新——这个视觉修正本身也已经真机确认：CC 测试
// 报告"M2（含按钮停用视觉）真机测试全数通过，无异常"，disabled 状态
// 现在视觉上真的看得出来，不再是"看似可用但按不到"。至此 BL-15
// 整体（mutation 路径 + 视觉修正）全部 VERIFIED，没有遗留待确认项目。
//
// 依赖：无新增 Domain/Bridge 行为。

// BL-16 — Mobile Defect Detail MVP，M3 Developer Status 写入（提出并
// 实作于 2026-09-09，M1-M5 第三个）
//
// 背景：M1（VERIFIED）、M2（mutation 路径 VERIFIED，视觉修正待重新
// 确认）之后，Owner 继续推进 M3。947/918 的 Developer Status 路径
// BL-13 起就已经支援 clientRequestId、真机验证过，这次逐字未动。
//
// 实作：完全比照 M2 Owner Verification 的既有交互模式——chip 选、
// 按钮才送，不是点了就送。四个选项对应
// PROPERTY_CONFIG.DEVELOPER_STATUSES 权威枚举（Pending/Scheduled/
// InProgress/ClaimedCompleted）本身，UI 上显示的"In Progress"/
// "Claimed Completed"只是给使用者看的友善文字，实际送进 947/918 的
// data-status 值是精确的 Domain 字串，没有另外发明或翻译。样式 100%
// 重用既有的 .ovchip（M2 建立）跟 .btn-secondary（含上一轮真机测试
// 后修好的 :disabled 规则）——这次从一开始就用对，没有重蹈 M2 那个
// "disabled 但看起来能点"的覆辙，零新增 CSS。
//
// 测试：947（22/22）、918（163/163）、922（67/67）逐字不受影响——
// Developer Status 的 server 端逻辑本来就没有新代码。948 的 client
// 端行为一样用静态核对：grep 确认零直接 Sheet 存取、零意外混入
// M4/M5（dlp_addRectificationEvent/dlp_attachDefectEvidence/
// dlp_addSecondaryDamage）、确认 dlp_recordDeveloperStatus 只在这次
// 新增的一处被呼叫、确认新的 #ds_chips 用的是已经验证过不会跟 Daily
// Check 既有 unscoped `.chip` selector 碰撞的 `.ovchip` class，这次
// 从设计阶段就避开了 M2 走过的弯路，不是事后才发现修正。
//
// 真机 / Real-GAS 验证：★ 2026-09-09 更新——VERIFIED。CC 测试报告
// "M3 真机测试全数通过，无异常"——这是 M3 第一次真的被真机验证，
// 不再只是"代码跟 M2 已验证过的东西长得一样"这种推论式的确定性
// （M3 报告 G 节当时特别诚实标注过这个差异，现在这个差异已经补上）。
//
// 依赖：无新增 Domain/Bridge 行为，无新增 CSS。

// BL-17 — Mobile DLP Console：Defect Search + A-Z/Z-A Sort（提出并
// 实作于 2026-09-09）
//
// 背景：Case 底下的 Defect 数量会累积，需要能快速用 Item ID/Category/
// Location/Description 等关键字定位特定 defect，加上按 Item ID 排序。
// 纯 read-side 强化，不属于 M1-M5 mutation 序列。
//
// 实作：完全 client-side、完全在既有的 state.allDefects 上操作——
// buildCaseOverviewForMobile_（922）本来就已经回传 itemId/category/
// subCategory/location/description/remark 全部欲搜寻栏位，零新增
// backend API、零改动 918/922/901。搜寻语意：多关键字之间 AND、单一
// 关键字内跨栏位 OR（关键字只要出现在任一可搜寻栏位就算命中），大小写
// 不敏感，不搜 CaseID/内部时间戳/clientRequestId 这类非使用者导向欄位。
// 排序预设键选 ItemID 而非卡片标题用的 Location——ItemID 是
// ADR-P19 定义的稳定 import/dedup identity，Location 只是显示用的
// 标题文字，多个 defect 完全可能共用同一个 Location，不构成 identity。
// 用 localeCompare({numeric:true}) 处理排序，不管 ItemID 实际是纯数字
// （"2"排在"10"前面）还是英数混合（"DEF-2"排在"DEF-10"前面）都正确，
// 不用事先假设真实资料格式。A-Z/Z-A 按钮设计成可以再按一次取消排序、
// 回到原始（未排序）顺序，不是只能三选一互斥。
//
// 测试：**这次是真的有可执行、非纯静态的本地测试**——
// defectMatchesQuery_/compareDefectsByItemId_/filterAndSortDefects_
// 三个函式刻意写成不碰 DOM 的纯函式，新建
// local_precheck_test_948_search.js，把 948 的 <script> 内容读进一个
// 最小 VM context（只 stub 了 document.addEventListener 让顶层那行
// 不报错，没有 stub google.script.run，因为这三个函式本来就不会碰到
// 它）直接呼叫这三个函式，29 项全过，包含真的执行验证"2"排在"10"前面
// （证明数字感知排序真的生效，不是只有设计意图）。DOM 相关的部分
// （render/setup 函式本体、无 per-keystroke RPC、M1/M2/M3 完整保留）
// 沿用 M1-M3 建立的静态 grep 核对方式。947/918/922 三个既有测试档案
// （22/163/67）逐字不受影响。
//
// Mobile UI Contract：判断不需要修订——Defect List 本来就是 Contract
// §1 已核准的只读范围，这次只是同一份已核准资料的新浏览/筛选方式，
// 没有新增任何写入能力、没有曝光 Secondary Damage/Correspondence，
// 没有变动已核准的 scope 边界本身。
//
// 真机验证：PENDING。M1/M2（mutation 路径）既有 VERIFIED 状态、M2
// 视觉修正的 RECHECK PENDING 状态都维持不变，未受这次改动影响。
//
// ★ 2026-09-14 更新：重新读过当前代码与 UI Contract 后，针对这个
// PENDING 状态设计了完整的真机验证方案（覆盖 Search/Sort/交互/
// M1-M3 regression/性能观察），见
// REPORT_2026-09-14_Step2-BL17-SearchSort-VerificationPlan.md。方案
// 本身不改变这里的状态——仍然是 PENDING，等 CC 实际执行后才更新。
// 同一次重新核对也把 local test 全部重跑确认：948_search 29/29、
// 947 22/22、918 163/163、922 67/67，跟原始报告数字一致，不是引用
// 旧数字。
//
// 依赖：无新增 Domain/Bridge/Schema 行为。
//
// ★★ 2026-09-14 真机验证 Closure：CC 在真实手机/真实 GAS 环境执行了
// 上面提到的验证方案，回报 Phase 0-5（对应方案里的 A-E）全部通过：
// Search（ItemID/关键词/大小写不敏感/无匹配/清空，均正常）、Sort
// （A-Z 确认是自然数字序 1,2...10 不是字典序、Z-A、再按一次取消，均
// 正常）、Search+Sort 两种顺序组合（先搜后排、先排后搜、清空搜索词
// 后排序状态保留）、M1-M3 回归（过滤后点卡片进入正确的 Detail、无
// 索引错位；M2/M3 提交与刷新正常）、手机端体感（打字与排序流畅、
// 无掉帧无白屏无报错）。Timeline 拆分明确：纯搜索/排序期间 0 笔
// 新增，M2 提交 +1、M3 提交 +1，两笔加总 2 笔——干净分开了
// "Search/Sort 零副作用"跟"M2/M3 domain mutation"这两件事，不是
// 混在一起报一个总数。
//
// 证据等级如实记录：以上是 CC 第一手真机操作的具体叙述（不是泛泛的
// "都过了"，包含正确的自然排序判断跟 Timeline 拆分逻辑），但不是
// 像 Step 1 Evidence 验证那样逐行可独立核对的原始 Execution Log——
// 方案原本要求记录的几项没有列出精确数字：这个 Case 实际的
// DefectItem 总数、排序结果的实际 ItemID 序列（只给了"1,2...10"
// 这个模式，不是真实清单）、各个 search 子情境命中的实际笔数。这些
// 如果之后要补，随时可以以 Addendum 形式加进来，跟这次的记录分开，
// 不会互相覆盖。
//
// 状态：Defect List Search / Sort 真机验证 PASS（证据等级：CC 第一手
// 具体叙述，非逐行原始 log）。DlpMobileConsole_UIContract.md §12
// 状态栏同步更新，不留 governance 与现实不一致的缺口。
//
// 明确停在这里：不自动进入 M4，等 CC 审阅后另行决定。

// BL-18 — 945 dlp_attachDefectEvidence 呼叫端补上 clientRequestId（登记于
// 2026-09-14，源自 Step 1 Evidence 真机验证时发现的观察；本轮只登记，
// 不实施）
//
// 背景：Step 1（2026-09-14）验证了 dlp_attachDefectEvidence 的
// clientRequestId 去重机制本身在真实 GAS 里正确（见 BL-13 Addendum 3、
// MANUAL_VERIFICATION_CHECKLIST.md）。但同一次验证也发现：945
// Sidebar 目前呼叫 dlp_attachDefectEvidence 时完全不带 clientRequestId
// 这个欄位，靠 Submit 按钮 disable 当唯一防线。对照之下，948 Mobile
// Daily Check 的 dlp_attachEvidence（不同的 947 wrapper，同样调用 911）
// 早就在呼叫时用 generateClientRequestId_() 生成并送出。两个 Evidence
// 相关 wrapper 目前的 idempotency propagation contract 不一致。
//
// 提议内容：945_OperatorConsole.html 的 evidence 上传呼叫端比照 948
// 既有作法，呼叫 dlp_attachDefectEvidence 前先用 generateClientRequestId_()
// 生成一个 clientRequestId 并放进呼叫参数。
//
// 范围（刻意维持最小，CC 明确要求）：
// - 仅修改 945_OperatorConsole.html 的呼叫端
// - 不改 911 / 918（后端已经支援，不需要新代码）
// - 不顺手重构 Evidence flow 的其他部分
// - 不提前实作其他 idempotency enhancement
//
// 状态：REGISTERED — NOT IMPLEMENTED。本轮（2026-09-14）只登记这个
// Backlog item，945 本身逐字未动。是否排入实际实作排程，等 CC 另行
// 授权。
//
// 依赖：无新增 Domain/Bridge/Schema 行为——911/918 已经支援
// clientRequestId，这次纯粹是让 945 也开始使用既有能力。

// BL-19 — Mobile DLP Console：M4 Rectification Event 提交（2026-09-14，
// 提出并实作，Option A only——见 GATE_2026-09-14_M4-RectificationEvent-
// ArchitectureReview.md 与 CC 的 Implementation Authorization）
//
// 背景：M4 是 Mobile Defect Detail 系列（M1 只读展开/BL-14、M2 Owner
// Verification/BL-15、M3 Developer Status/BL-16）里第一个需要写入的
// EventType 枚举（而非既有 Status 枚举）的 slice。Architecture Gate 已经
//确认：RectificationEvent 这个 Entity、其 Schema、其 clientRequestId
// 幂等层，全部早就存在且已在 945 Sidebar 活跃使用、已在 BL-13
// （2026-09-08）真机验证过——本次 M4 严格只是「给这个既有能力接一个
// Mobile UI」，不是新的 Domain 设计。
//
// 内容：948_MobileConsole.html 新增一个 chip-then-submit 区块（"Log
// Rectification Event"），紧接在既有的唯读 Rectification Events 历史
// 清单之后、Evidence 区块之前。7 个 chip 对应 PROPERTY_CONFIG.
// RECTIFICATION_EVENT_TYPES 逐字（AccessRequested/AccessGranted/
// RectificationStarted/RectificationCompleted/RectificationRejected/
// ReinspectionRequired/DeveloperClaimedCompleted），额外一个可选 Notes
// 栏位（复用既有 Daily Check 的 textarea 样式，未新增任何 CSS）。呼叫
// 既有 dlp_addRectificationEvent（947，逐字未动），自己生成
// clientRequestId（`generateClientRequestId_()`，跟 M2/M3 完全同一个
// 函式、同一个"同一次尝试重试沿用同一个 ID、成功后清空等下一次尝试
// 重新生成"生命周期）。openDefectDetail_ 补上跟 M2/M3 对称的 4 项状态
// 重置（选取状态、clientRequestId、chip 视觉、Notes 栏位内容），确保
// 每次打开 Detail 都是干净的边界，不会让上一个 defect 或上一次成功
// 提交的残留状态漏进下一次操作。
//
// 明确没有做的（HARD SCOPE BOUNDARY，逐条对照 Authorization）：
// 没有建立 Repair Cycle Entity；没有动 DefectItem schema；没有新增
// Sheet；没有动 DeveloperStatus/OwnerVerificationStatus 架构；没有把
// Status 改成 Event projection；没有动 ADR-P15；没有重构或重写
// logRectificationEvent（918 逐字未动）；没有动 922 business logic
// （922 逐字未动，本来就已经在读 RectificationEvent 做 Dashboard 聚合，
// 不需要因为多一个写入来源而改）；没有动 EventBus/Evidence 架构；没有
// 实施 BL-18；没有修 945 既有的 clientRequestId 缺口（Architecture Gate
// 已经点出来，本次刻意不动，跟 BL-18 一样是独立、未处理的既有缺口）；
// 没有新增第二套 idempotency 机制（完全复用 918 既有的
// getCachedDefectEngineCommandResult_/cacheDefectEngineCommandResult_）。
//
// 本地测试：新建 local_precheck_test_948_rectification.js（27 项，含
// 全部 7 个 EventType 逐一真的透过 dlp_addRectificationEvent 提交成功、
// Notes 栏位端到端保真、对 948_MobileConsole.html 原始碼的静态核对
// ——clientRequestId 生成与传递、Notes 传递、openDefectDetail_ 状态
// 重置、setupRectificationEvent_ 确实被呼叫、M2/M3 呼叫形状未被误动
// 的回归防线）。重新实际跑过既有三个套件确认零回归：918 163/163、
// 947 22/22、948_search 29/29。M4-03（缺栏位拒绝）/M4-04（无效
// DefectID 拒绝）/M4-07（呼叫端重复不产生第二次 mutation）三项，因为
// 918/947 既有测试套件本来就已经涵盖同一个 logRectificationEvent/
// dlp_addRectificationEvent 路径，没有重复新写测试——沿用既有覆盖，
// 不是没测。
//
// 状态：IMPLEMENTED — LOCAL VERIFIED — GAS VERIFICATION PENDING。真机
// 验证程序已经在 IMPLEMENTATION_2026-09-14_M4-RectificationEvent.md
// 里备妥（A 首次提交/B 相同 clientRequestId 重复/C 新 clientRequestId/
// D M1-M3 回归），尚未执行，不自动宣告 Production Verified/Production
// Ready。
//
// 依赖：无新增 Domain/Bridge/Schema 行为——完全复用 918/947 既有能力。

// ★★ 2026-09-18 真机验证 Closure（D 项确认，A-D 全部到齐）：CC 已于
// 2026-09-16 回报 A/B/C（Sheet 行数模式：首次提交 +1、同一
// clientRequestId 重打 +0/结果相同、换新 clientRequestId +1，对应
// 手机端实际提交一次与历史查看正常）——这部分已由 Claude 独立核对
// 行数模式的诊断力，视为可信。本次（2026-09-18）CC 逐项回报 D
// （M1-M3 回归 + 联动）：M1 详情展开正常（卡片点击即开、排版完整、
// 无白屏）；M2 Owner Verification 正常（chip 点选激活按钮、提交后
// 提示并刷新状态）；M3 Developer Status 正常（同上模式）；导航与
// 卡片联动正常（返回 Overview 后卡片徽标同步更新、返回首页顺畅）；
// Timeline 增量对应产生记录、无异常报错。至此 CC 自己在
// IMPLEMENTATION_2026-09-14_M4-RectificationEvent.md 定义的 A-D
// 真机验证程序全部完成。
//
// 证据等级如实记录：以上是 CC 第一手真机操作的具体叙述（逐项区分
// M1/M2/M3/导航/Timeline，不是笼统"都过了"），但不是逐行可独立
// 核对的原始 Execution Log——D 项未给出本次使用的具体 DefectID，
// 未给出 Timeline 行数的精确计数（只说"对应产生记录，无异常报错"，
// 跟 A/B/C 当时"各只 +1 行"的量化说法不同层级）。这些如果之后要
// 补，可以用 Addendum 形式加入，不影响本次 Closure。
//
// 状态：M4（Rectification Event Mobile 提交，BL-19）真机验证 PASS
// （A-D 全部完成；证据等级：CC 第一手具体叙述，非逐行原始 log）。
// DlpMobileConsole_UIContract.md §12、MANUAL_VERIFICATION_CHECKLIST.md
// 状态栏同步更新，不留 governance 与现实不一致的缺口。
//
// 明确停在这里：不自动进入 M5，也不自动处理 BL-18 或 945 既有的
// Rectification Event clientRequestId 缺口——三者都需要 CC 另行
// 明确授权。

// BL-20 — 945 dlp_addRectificationEvent 呼叫端补上 clientRequestId（登记于
// 2026-09-20，源自专项核对时直接重读代码发现的观察；本轮只登记，不实施）
//
// 背景：BL-13（2026-09-08）当时 Owner 核准的决定，是让 947 的
// dlp_addRectificationEvent 与 dlp_attachDefectEvidence 这两个 wrapper
// 都把 clientRequestId 转传给 918/911——这部分已经完成，直接重读 947
// 目前代码确认 dlp_addRectificationEvent（281-296 行）确实已经在转传
// input.clientRequestId。但 Bridge 层接上，不等于 Caller 层会送——直接
// 重读 945_OperatorConsole.html 的 submitDlpAddRectificationEvent
// （1186-1210 行）确认它组出的 input 物件完全没有 clientRequestId 这个
// 欄位，跟 918 的 logRectificationEvent（918_DefectEngine.js 1374 行起）
// 早就支援、也早就在用的幂等 cache 机制（1378-1379、1452 行）完全没有
// 接上。对照 948 M4（BL-19）的 submitRectificationEvent_，一样呼叫
// dlp_addRectificationEvent，但会先用 generateClientRequestId_() 产生
// 一个值再放进呼叫参数（948_MobileConsole.html 1191、1222-1226 行）。
// 两个呼叫端（945/948）打同一个 Bridge、同一个 918 Domain Command，目前
// 呼叫参数不一致。
//
// 证据等级：E1——本轮直接重读 945/947/918/948 现有代码得出（行号如上），
// 不是沿用旧报告或猜测。BL-19 背景段落有一句提到 RectificationEvent 的
// clientRequestId 幂等层"已在 945 Sidebar 活跃使用"，读起来容易被误解成
// 945 呼叫端已经在送这个欄位——直接重读 945 目前代码后，这句更准确的
// 理解应该是「Entity/Schema 已经在 945 使用」，不是「呼叫端已经送
// clientRequestId」。本条目以这次直接重读的 E1 结果为准。
//
// 这跟 BL-18（945 的 Evidence 呼叫端缺口）是同一个模式（945 呼叫端没接
// 上既有能力），但不是同一个呼叫端、也不是同一个 Backend Command——BL-18
// 管的是 dlp_attachDefectEvidence/911，这里管的是
// dlp_addRectificationEvent/918。两者是兄弟缺口，不是同一个 item，分开
// 登记。BL-18 relationship: NOT EXPLICITLY IN SCOPE（BL-18 本文明确把
// 范围限定在 Evidence 呼叫端，逐字没有提到 Rectification Event）。
//
// 明确不是什么（避免误读成更大的问题）：这不是「918 幂等机制坏了」、不是
// 「945 目前会产生重复 RectificationEvent」、不是「业务资料已经损坏」、
// 也不是「M4/948 有缺陷」——现有代码没有任何证据支持这几点，945 现在的
// 唯一防线是 Submit 按钮 disable（跟 BL-18 当时对 Evidence 的描述完全
// 一样的情况）。分类是「Caller 端幂等传播缺口」，不是「Backend 幂等
// 失效」。
//
// 提议内容（未来实作，本轮不动手）：945_OperatorConsole.html 的
// submitDlpAddRectificationEvent 比照 948 既有作法与 BL-18 已经提议的
// 模式，呼叫 dlp_addRectificationEvent 前先用 generateClientRequestId_()
// 生成一个 clientRequestId 并放进呼叫参数。
//
// 范围（刻意维持最小，比照 BL-18 先例）：
// - 仅修改 945_OperatorConsole.html 的 submitDlpAddRectificationEvent
//   呼叫端
// - 不改 918（Backend 已经支援，不需要新代码——已直接重读代码确认）
// - 不改 947 的 dlp_addRectificationEvent（Bridge 层已经支援转传，
//   BL-13 时就做好了——已直接重读代码确认）
// - 不改 BL-18（两者是独立 item，即使未来实作时可能顺手一起做，登记
//   必须分开）
// - 不顺手重构 Rectification Event flow 的其他部分
// - 不提前实作其他 idempotency enhancement
// - 不涉及 M5 Evidence Mobile
//
// 验收标准（未来实作完成后才适用，本轮不执行）：
// 1. 945 的 Rectification Event submission 会产生一个有效、唯一的
//    clientRequestId。
// 2. 这个值会转传给既有的 918 logRectificationEvent 呼叫。
// 3. 918 backend 保持不变，除非未来另有分析证明需要改。
// 4. 用同一个 clientRequestId 重复提交时，行为符合既有 918 幂等
//    contract。
// 5. 有真实 GAS 验证（不是只有 local test）确认上述行为。
// 6. 如果既有 918 contract 是「同 clientRequestId 不建重复记录」，则
//    重复提交不应该产生第二笔 RectificationEvent。
// 7. 证据需要跟本地/unit test 结果分开记录，比照 BL-19 的证据分级写法。
//
// 状态：REGISTERED — NOT STARTED。本轮（2026-09-20）只登记这个 Backlog
// item，945 本身逐字未动。是否排入实际实作排程、是否与 BL-18 一起做，
// 等 CC 另行授权。
//
// 依赖：无新增 Domain/Bridge/Schema 行为——918（Domain）与 947（Bridge）
// 已经支援 clientRequestId，这次纯粹是让 945 的 Rectification Event
// 呼叫端也开始使用既有能力。
//
// 相关 item：BL-18（同模式的兄弟缺口，Evidence 呼叫端）、BL-19（M4，
// 948 侧已经在用同一个 918 Command 的对照组，是这次比对的依据）。
